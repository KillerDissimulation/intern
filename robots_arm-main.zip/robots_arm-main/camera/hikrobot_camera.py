"""Hikrobot/MVS camera source for the DOBOT Vision Kit."""

from __future__ import annotations

import os
import sys
import time
from ctypes import POINTER, byref, c_ubyte, cast, memset, sizeof
from pathlib import Path

import cv2
import numpy as np

import config
from .base_camera import BaseCamera


_DLL_DIRECTORIES = []


def decode_text(value) -> str:
    return bytes(value).split(b"\0", 1)[0].decode("utf-8", errors="replace")


def require_ok(code: int, action: str) -> None:
    if code != 0:
        raise RuntimeError(f"{action} failed with MVS error 0x{code & 0xFFFFFFFF:08X}")


def load_mvs_sdk():
    sdk_root = Path(os.environ.get("MVS_SDK_ROOT", config.MVS_SDK_ROOT))
    runtime = Path(os.environ.get("MVS_RUNTIME", config.MVS_RUNTIME))
    configured_python = config.MVS_PYTHON
    python_dir = Path(
        os.environ.get(
            "MVS_PYTHON",
            configured_python
            or sdk_root / "Development" / "Samples" / "Python" / "MvImport",
        )
    )
    if not python_dir.exists():
        raise RuntimeError(
            "Hikrobot MVS SDK not found. Install MVS and configure the Python SDK path."
        )
    if str(python_dir) not in sys.path:
        sys.path.insert(0, str(python_dir))
    if not runtime.exists():
        raise RuntimeError(
            "Hikrobot MVS runtime not found. Install MVS or set MVS_RUNTIME."
        )
    os.environ["PATH"] = str(runtime) + os.pathsep + os.environ.get("PATH", "")
    if hasattr(os, "add_dll_directory"):
        _DLL_DIRECTORIES.append(os.add_dll_directory(str(runtime)))
    try:
        import CameraParams_const as constants
        import MvCameraControl_class as sdk
        import PixelType_header as pixel_types
    except ImportError as error:
        raise RuntimeError(
            "Hikrobot MVS SDK Python files could not be imported. "
            "Set MVS_PYTHON to the folder containing MvCameraControl_class.py."
        ) from error
    return sdk, constants, pixel_types


def mvs_sdk_available() -> tuple[bool, str]:
    try:
        load_mvs_sdk()
    except Exception as error:
        return False, str(error)
    return True, "MVS SDK available"


def _device_info(sdk, constants, device) -> dict:
    layer = int(device.nTLayerType)
    if layer == constants.MV_GIGE_DEVICE:
        info = device.SpecialInfo.stGigEInfo
        return {
            "type": "GigE",
            "model": decode_text(info.chModelName),
            "serial": decode_text(info.chSerialNumber),
        }
    if layer == constants.MV_USB_DEVICE:
        info = device.SpecialInfo.stUsb3VInfo
        return {
            "type": "USB",
            "model": decode_text(info.chModelName),
            "serial": decode_text(info.chSerialNumber),
        }
    return {"type": f"Layer {layer}", "model": "Unknown", "serial": ""}


def list_hikrobot_devices() -> list[dict]:
    sdk, constants, _ = load_mvs_sdk()
    require_ok(sdk.MvCamera.MV_CC_Initialize(), "Initialize MVS SDK")
    try:
        devices = sdk.MV_CC_DEVICE_INFO_LIST()
        layer_mask = constants.MV_GIGE_DEVICE | constants.MV_USB_DEVICE
        require_ok(
            sdk.MvCamera.MV_CC_EnumDevices(layer_mask, devices),
            "Enumerate Hikrobot cameras",
        )
        found = []
        for index in range(devices.nDeviceNum):
            device = cast(
                devices.pDeviceInfo[index], POINTER(sdk.MV_CC_DEVICE_INFO)
            ).contents
            item = _device_info(sdk, constants, device)
            item["index"] = index
            found.append(item)
        return found
    finally:
        sdk.MvCamera.MV_CC_Finalize()


class HikrobotCamera(BaseCamera):
    name = "hikrobot"

    def __init__(
        self,
        device_index: int = 0,
        serial: str | None = None,
        timeout_ms: int = 3000,
    ):
        self.device_index = device_index
        self.requested_serial = serial
        self.timeout_ms = timeout_ms
        self.sdk = None
        self.constants = None
        self.pixel_types = None
        self.camera = None
        self.handle_created = False
        self.opened = False
        self.grabbing = False
        self.model = ""
        self.serial = ""
        self.device_type = ""

    def open(self) -> None:
        if self.is_opened():
            return
        self.sdk, self.constants, self.pixel_types = load_mvs_sdk()
        sdk = self.sdk
        constants = self.constants
        require_ok(sdk.MvCamera.MV_CC_Initialize(), "Initialize MVS SDK")
        try:
            devices = sdk.MV_CC_DEVICE_INFO_LIST()
            layer_mask = constants.MV_GIGE_DEVICE | constants.MV_USB_DEVICE
            require_ok(
                sdk.MvCamera.MV_CC_EnumDevices(layer_mask, devices),
                "Enumerate Hikrobot cameras",
            )
            if devices.nDeviceNum == 0:
                raise RuntimeError("No Hikrobot/MVS camera detected")

            selected = None
            selected_info = None
            for index in range(devices.nDeviceNum):
                device = cast(
                    devices.pDeviceInfo[index], POINTER(sdk.MV_CC_DEVICE_INFO)
                ).contents
                info = _device_info(sdk, constants, device)
                if self.requested_serial and info["serial"] == self.requested_serial:
                    selected = device
                    selected_info = info
                    break
                if not self.requested_serial and index == self.device_index:
                    selected = device
                    selected_info = info
                    break
            if selected is None:
                raise RuntimeError("Requested Hikrobot/MVS camera was not found")

            self.model = selected_info["model"]
            self.serial = selected_info["serial"]
            self.device_type = selected_info["type"]
            self.camera = sdk.MvCamera()
            require_ok(self.camera.MV_CC_CreateHandle(selected), "Create camera handle")
            self.handle_created = True
            require_ok(self.camera.MV_CC_OpenDevice(constants.MV_ACCESS_Exclusive, 0), "Open camera")
            self.opened = True

            if selected.nTLayerType == constants.MV_GIGE_DEVICE:
                packet_size = self.camera.MV_CC_GetOptimalPacketSize()
                if packet_size > 0:
                    require_ok(
                        self.camera.MV_CC_SetIntValue("GevSCPSPacketSize", packet_size),
                        "Set GigE packet size",
                    )

            require_ok(
                self.camera.MV_CC_SetEnumValue("TriggerMode", sdk.MV_TRIGGER_MODE_OFF),
                "Disable trigger mode",
            )
            require_ok(self.camera.MV_CC_SetBayerCvtQuality(1), "Set Bayer conversion")
            require_ok(self.camera.MV_CC_StartGrabbing(), "Start acquisition")
            self.grabbing = True
            time.sleep(0.3)
            print(
                f"[CAMERA] Hikrobot Vision Kit opened: {self.model} "
                f"({self.serial}, {self.device_type})"
            )
        except Exception:
            self.close()
            raise

    def read(self):
        if not self.is_opened():
            return False, None
        output = self.sdk.MV_FRAME_OUT()
        memset(byref(output), 0, sizeof(output))
        code = self.camera.MV_CC_GetImageBuffer(output, self.timeout_ms)
        if code != 0:
            return False, None
        try:
            frame = self._frame_to_bgr(output)
            return True, frame
        finally:
            self.camera.MV_CC_FreeImageBuffer(output)

    def _frame_to_bgr(self, output):
        width = int(output.stFrameInfo.nWidth)
        height = int(output.stFrameInfo.nHeight)
        pixel_type = int(output.stFrameInfo.enPixelType)

        if pixel_type == self.pixel_types.PixelType_Gvsp_Mono8:
            mono = np.ctypeslib.as_array(
                cast(output.pBufAddr, POINTER(c_ubyte)),
                shape=(height * width,),
            ).reshape(height, width)
            return cv2.cvtColor(mono.copy(), cv2.COLOR_GRAY2BGR)

        if pixel_type == self.pixel_types.PixelType_Gvsp_BGR8_Packed:
            bgr = np.ctypeslib.as_array(
                cast(output.pBufAddr, POINTER(c_ubyte)),
                shape=(height * width * 3,),
            ).reshape(height, width, 3)
            return bgr.copy()

        rgb_size = width * height * 3
        rgb_buffer = (c_ubyte * rgb_size)()
        conversion = self.sdk.MV_CC_PIXEL_CONVERT_PARAM_EX()
        memset(byref(conversion), 0, sizeof(conversion))
        conversion.nWidth = width
        conversion.nHeight = height
        conversion.pSrcData = output.pBufAddr
        conversion.nSrcDataLen = output.stFrameInfo.nFrameLen
        conversion.enSrcPixelType = output.stFrameInfo.enPixelType
        conversion.enDstPixelType = self.pixel_types.PixelType_Gvsp_RGB8_Packed
        conversion.pDstBuffer = rgb_buffer
        conversion.nDstBufferSize = rgb_size
        require_ok(self.camera.MV_CC_ConvertPixelTypeEx(conversion), "Convert frame")
        rgb = np.ctypeslib.as_array(rgb_buffer)[: conversion.nDstLen]
        rgb = rgb.reshape(height, width, 3)
        return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)

    def close(self) -> None:
        if self.camera is not None:
            if self.grabbing:
                self.camera.MV_CC_StopGrabbing()
                self.grabbing = False
            if self.opened:
                self.camera.MV_CC_CloseDevice()
                self.opened = False
            if self.handle_created:
                self.camera.MV_CC_DestroyHandle()
                self.handle_created = False
            self.camera = None
        if self.sdk is not None:
            self.sdk.MvCamera.MV_CC_Finalize()
            self.sdk = None

    def is_opened(self) -> bool:
        return self.camera is not None and self.opened and self.grabbing
