"""OpenCV VideoCapture camera source."""

from __future__ import annotations

import cv2

from .base_camera import BaseCamera


class OpenCVCamera(BaseCamera):
    name = "opencv"

    def __init__(
        self,
        index: int = 0,
        width: int | None = None,
        height: int | None = None,
        fps: int | None = None,
    ):
        self.index = index
        self.width = width
        self.height = height
        self.fps = fps
        self.capture = None
        self.model = f"OpenCV camera {index}"
        self.serial = str(index)

    def open(self) -> None:
        if self.capture is not None and self.capture.isOpened():
            return
        capture = cv2.VideoCapture(self.index, cv2.CAP_DSHOW)
        if self.width:
            capture.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        if self.height:
            capture.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        if self.fps:
            capture.set(cv2.CAP_PROP_FPS, self.fps)
        if not capture.isOpened():
            capture.release()
            raise RuntimeError(f"OpenCV camera {self.index} could not be opened")
        self.capture = capture
        print(f"[CAMERA] OpenCV camera opened: index {self.index}")

    def read(self):
        if self.capture is None or not self.capture.isOpened():
            return False, None
        success, frame = self.capture.read()
        if not success or frame is None:
            return False, None
        return True, frame

    def close(self) -> None:
        if self.capture is not None:
            self.capture.release()
            self.capture = None

    def is_opened(self) -> bool:
        return self.capture is not None and self.capture.isOpened()


def detect_opencv_cameras(max_index: int = 5) -> list[int]:
    found = []
    for index in range(max_index + 1):
        capture = cv2.VideoCapture(index, cv2.CAP_DSHOW)
        try:
            if capture.isOpened():
                success, _ = capture.read()
                if success:
                    found.append(index)
        finally:
            capture.release()
    return found
