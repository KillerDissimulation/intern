"""Common camera interface used by the vision and robot game code."""

from __future__ import annotations

from abc import ABC, abstractmethod


class BaseCamera(ABC):
    name = "camera"
    model = ""
    serial = ""

    @abstractmethod
    def open(self) -> None:
        """Open the camera and prepare it for frame capture."""

    @abstractmethod
    def read(self):
        """Return (success, frame), where frame is an OpenCV BGR image."""

    @abstractmethod
    def close(self) -> None:
        """Release all camera resources."""

    @abstractmethod
    def is_opened(self) -> bool:
        """Return True when the camera is currently open."""

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, *_):
        self.close()
