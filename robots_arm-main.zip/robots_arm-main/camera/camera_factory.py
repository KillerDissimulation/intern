"""Camera factory for OpenCV and Hikrobot camera sources."""

from __future__ import annotations

import config
from .opencv_camera import OpenCVCamera


def create_camera(
    camera_type: str = config.CAMERA_TYPE,
    camera_index: int = config.CAMERA_INDEX,
    width: int | None = config.CAMERA_WIDTH,
    height: int | None = config.CAMERA_HEIGHT,
    fps: int | None = config.CAMERA_FPS,
    mvs_device_index: int = config.MVS_DEVICE_INDEX,
    hikrobot_serial: str | None = config.HIKROBOT_SERIAL,
):
    camera_type = camera_type.lower().strip()
    if camera_type == "opencv":
        camera = OpenCVCamera(camera_index, width, height, fps)
        camera.open()
        return camera

    if camera_type == "hikrobot":
        from .hikrobot_camera import HikrobotCamera

        camera = HikrobotCamera(mvs_device_index, hikrobot_serial)
        camera.open()
        return camera

    if camera_type == "auto":
        try:
            from .hikrobot_camera import HikrobotCamera

            camera = HikrobotCamera(mvs_device_index, hikrobot_serial)
            camera.open()
            print("[CAMERA] Hikrobot Vision Kit detected")
            return camera
        except Exception as error:
            print(f"[CAMERA] Hikrobot camera not detected: {error}")
            print(f"[CAMERA] Falling back to OpenCV camera {camera_index}")
            camera = OpenCVCamera(camera_index, width, height, fps)
            camera.open()
            return camera

    raise ValueError("camera_type must be auto, opencv, or hikrobot")
