"""Unified camera sources for the 4x4 MG400 project."""

from .camera_factory import create_camera

__all__ = ["create_camera"]
