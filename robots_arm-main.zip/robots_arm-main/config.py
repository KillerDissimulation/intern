"""Project-wide defaults for camera acquisition and vision tests."""

CAMERA_TYPE = "auto"  # auto, opencv, hikrobot
CAMERA_INDEX = 0
CAMERA_WIDTH = 1280
CAMERA_HEIGHT = 720
CAMERA_FPS = 30

HIKROBOT_SERIAL = None
MVS_DEVICE_INDEX = 0
MVS_SDK_ROOT = r"C:\Program Files (x86)\MVS"
MVS_RUNTIME = r"C:\Program Files (x86)\Common Files\MVS\Runtime\Win64_x64"
MVS_PYTHON = None

BOARD_ROWS = 4
BOARD_COLS = 4
CHECKERBOARD_INNER_CORNERS = (4, 4)

CALIBRATION_FILE = "board_calibration.json"
