"""Continuous local camera-to-MG400 4x4 block game.

Default mode is a safe simulation: the camera detects turns and writes
planned_robot_move.json, but the physical robot is not commanded unless
EXECUTE_ROBOT is changed to True or --execute is passed.
"""

from __future__ import annotations

import argparse
import json
import os
import queue
import threading
import time
from pathlib import Path

import cv2
import numpy as np

import config
from bots_move import connect_robot, execute_move, go_to_start, set_wait_scale
from camera.camera_factory import create_camera
from checkerboard_grid import detect_4x4_board, draw_detected_board, score_4x4_board
from mvs_grid_rules_live import (
    BoardCalibration,
    GRID_SIZE,
    cell_name,
    draw_robot_coordinates,
    follows_movement_rule,
    validate_move,
)
from mvs_yolo_live import detect_color_blocks, fit_preview


EXECUTE_ROBOT = False
DEBUG = False
STABLE_FRAMES = 5
ROBOT_VERIFY_TIMEOUT = 30.0
DEFAULT_SPEED = 60
DEFAULT_WAIT_SCALE = 0.6
MIN_GREEN_BLOCKS = 1
MIN_BLUE_BLOCKS = 1
MAX_GREEN_BLOCKS = None
MAX_BLUE_BLOCKS = None

INITIALIZING = "INITIALIZING"
WAITING_FOR_HUMAN = "WAITING_FOR_HUMAN"
HUMAN_MOVE_DETECTED = "HUMAN_MOVE_DETECTED"
PLANNING_ROBOT_MOVE = "PLANNING_ROBOT_MOVE"
WAITING_FOR_ROBOT = "WAITING_FOR_ROBOT"
VERIFYING_ROBOT_MOVE = "VERIFYING_ROBOT_MOVE"
RESETTING_BOARD = "RESETTING_BOARD"
STOPPED = "STOPPED"
ERROR = "ERROR"

HUMAN_LABEL = "blue block"
ROBOT_LABEL = "green block"
LABELS = (HUMAN_LABEL, ROBOT_LABEL)
RESET_LABEL_ORDER = (ROBOT_LABEL, HUMAN_LABEL)
PIECE_COUNT_LIMITS: dict[str, tuple[int, int | None]] = {
    ROBOT_LABEL: (MIN_GREEN_BLOCKS, MAX_GREEN_BLOCKS),
    HUMAN_LABEL: (MIN_BLUE_BLOCKS, MAX_BLUE_BLOCKS),
}
STARTING_BOARD = {
    ROBOT_LABEL: ((0, 1), (0, 3)),  # A2, A4
    HUMAN_LABEL: ((3, 0), (3, 2)),  # D1, D3
}


def parse_cell_name(name: str) -> tuple[int, int]:
    text = name.strip().upper()
    if len(text) != 2 or text[0] not in "ABCD" or text[1] not in "1234":
        raise ValueError("Target square must be A1 through D4")
    return ord(text[0]) - ord("A"), int(text[1]) - 1


def parse_optional_max(value: str) -> int | None:
    text = str(value).strip().lower()
    if text in ("none", "no", "unlimited", "all"):
        return None
    maximum = int(text)
    if maximum < 0:
        raise argparse.ArgumentTypeError("max block count must be non-negative or none")
    return maximum


def all_cells() -> list[tuple[int, int]]:
    return [(column, row) for row in range(GRID_SIZE) for column in range(GRID_SIZE)]


def empty_board_state() -> dict[str, tuple[tuple[int, int], ...]]:
    return {label: tuple() for label in LABELS}


def normalize_board_state(
    cells_by_label: dict[str, list[tuple[int, int]]],
) -> dict[str, tuple[tuple[int, int], ...]]:
    state = empty_board_state()
    for label in RESET_LABEL_ORDER:
        state[label] = tuple(sorted(set(cells_by_label.get(label, []))))
    return state


def board_signature(board_state: dict[str, tuple[tuple[int, int], ...]]) -> tuple:
    return tuple((label, board_state.get(label, tuple())) for label in LABELS)


def same_board(
    first: dict[str, tuple[tuple[int, int], ...]],
    second: dict[str, tuple[tuple[int, int], ...]],
) -> bool:
    return board_signature(first) == board_signature(second)


def format_cells(cells: tuple[tuple[int, int], ...]) -> str:
    if not cells:
        return "(none)"
    return " ".join(cell_name(cell) for cell in cells)


def print_board_state(title: str, board_state: dict[str, tuple[tuple[int, int], ...]]) -> None:
    print(f"\n=== {title} ===")
    print(f"Blue:  {format_cells(board_state[HUMAN_LABEL])}")
    print(f"Green: {format_cells(board_state[ROBOT_LABEL])}")


def validate_piece_counts(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    limits: dict[str, tuple[int, int | None]] | None = None,
) -> tuple[bool, str]:
    limits = PIECE_COUNT_LIMITS if limits is None else limits
    for label, (minimum, maximum) in limits.items():
        count = len(board_state[label])
        color = "green" if label == ROBOT_LABEL else "blue"
        if count < minimum:
            return False, f"Expected at least {minimum} {color} block(s), saw {count}"
        if maximum is not None and count > maximum:
            return False, f"Expected at most {maximum} {color} block(s), saw {count}"
    occupied = list(board_state[HUMAN_LABEL]) + list(board_state[ROBOT_LABEL])
    if len(occupied) != len(set(occupied)):
        return False, "A square appears to contain both blue and green"
    return True, "piece counts OK"


def log_debug(message: str) -> None:
    if DEBUG:
        print(f"[DEBUG] {message}")


class StableBoardTracker:
    def __init__(self, required_frames: int):
        self.required_frames = required_frames
        self.candidate = None
        self.count = 0

    def update(self, board_state: dict[str, tuple[tuple[int, int], ...]]) -> bool:
        signature = board_signature(board_state)
        if signature == self.candidate:
            self.count += 1
        else:
            self.candidate = signature
            self.count = 1
        return self.count >= self.required_frames

    def reset(self) -> None:
        self.candidate = None
        self.count = 0


def get_board_state(frame, calibration: BoardCalibration):
    annotated, detections = detect_color_blocks(frame)
    cells_by_label = {label: [] for label in LABELS}
    for detection in detections:
        label = detection["label"]
        if label not in LABELS:
            continue
        cell = calibration.pixel_to_cell(detection["center"])
        if cell is not None:
            cells_by_label[label].append(cell)
    return annotated, detections, normalize_board_state(cells_by_label)


def read_camera_frame(camera):
    success, frame = camera.read()
    if not success or frame is None:
        raise RuntimeError("Camera frame was not available")
    return frame


def capture_stable_board(
    camera,
    calibration: BoardCalibration,
    required_frames: int,
    no_window: bool,
    state: str,
    status: str,
) -> tuple[dict[str, tuple[tuple[int, int], ...]], object, list[dict]]:
    tracker = StableBoardTracker(required_frames)
    print(status)
    while True:
        frame = read_camera_frame(camera)
        latest, detections, board_state = get_board_state(frame, calibration)
        draw_robot_coordinates(latest, detections, calibration)
        draw_game_overlay(latest, calibration, state, status)
        if not no_window:
            cv2.imshow("4x4 Camera Robot Game", fit_preview(latest))
            if stop_key_pressed():
                raise KeyboardInterrupt
        if tracker.update(board_state):
            return board_state, latest, detections


def detect_human_move(
    previous_board: dict[str, tuple[tuple[int, int], ...]],
    current_board: dict[str, tuple[tuple[int, int], ...]],
) -> tuple[dict | None, str | None]:
    if same_board(previous_board, current_board):
        return None, None

    previous_green = set(previous_board[ROBOT_LABEL])
    current_green = set(current_board[ROBOT_LABEL])
    if previous_green != current_green:
        return None, "Green block changed during the human turn"

    previous_blue = set(previous_board[HUMAN_LABEL])
    current_blue = set(current_board[HUMAN_LABEL])
    removed = sorted(previous_blue - current_blue)
    added = sorted(current_blue - previous_blue)

    if len(removed) != 1 or len(added) != 1:
        return None, "Expected exactly one blue block source and one blue block target"

    return {
        "actor": "HUMAN",
        "label": HUMAN_LABEL,
        "start": removed[0],
        "target": added[0],
        "is_capture": added[0] in previous_green,
    }, None


def validate_human_move(
    previous_board: dict[str, tuple[tuple[int, int], ...]],
    current_board: dict[str, tuple[tuple[int, int], ...]],
    move: dict,
    limits: dict[str, tuple[int, int | None]] | None = None,
) -> tuple[bool, str]:
    valid_counts, count_reason = validate_piece_counts(current_board, limits)
    if not valid_counts:
        return False, count_reason
    if move["start"] not in previous_board[HUMAN_LABEL]:
        return False, "Source square did not previously contain a blue block"
    if move["target"] not in current_board[HUMAN_LABEL]:
        return False, "Target square does not currently contain a blue block"
    allowed, reason = validate_move("HUMAN", HUMAN_LABEL, move["start"], move["target"])
    if not allowed:
        return False, reason
    return True, "legal move"


def choose_robot_move(
    board_state: dict[str, tuple[tuple[int, int], ...]],
) -> tuple[tuple[int, int], tuple[int, int]]:
    """Choose a deterministic legal green move that can be replaced later."""
    green_cells = board_state[ROBOT_LABEL]
    if not green_cells:
        raise ValueError("No green block was detected for the robot move")

    occupied = set(board_state[HUMAN_LABEL]) | set(board_state[ROBOT_LABEL])
    options = []
    for start in green_cells:
        for target in all_cells():
            target_occupant = occupant_at(board_state, target)
            if target_occupant == ROBOT_LABEL:
                continue
            if not follows_movement_rule(ROBOT_LABEL, start, target):
                continue
            is_capture = target_occupant == HUMAN_LABEL
            distance = abs(target[0] - start[0]) + abs(target[1] - start[1])
            options.append(
                (
                    -int(is_capture),
                    -distance,
                    target[1],
                    target[0],
                    start[1],
                    start[0],
                    start,
                    target,
                )
            )

    if not options:
        raise ValueError("No legal empty diagonal green move is available")

    *_, start, target = min(options)
    return start, target


def apply_robot_move_to_board(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    start: tuple[int, int],
    target: tuple[int, int],
    label: str = ROBOT_LABEL,
) -> dict[str, tuple[tuple[int, int], ...]]:
    updated = {label: list(cells) for label, cells in board_state.items()}
    updated[label] = [cell for cell in updated[label] if cell != start]
    updated[label].append(target)
    for other_label in LABELS:
        if other_label != label:
            updated[other_label] = [
                cell for cell in updated[other_label] if cell != target
            ]
    return normalize_board_state(updated)


def occupant_at(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    cell: tuple[int, int],
) -> str | None:
    for label in LABELS:
        if cell in board_state[label]:
            return label
    return None


def is_required_target(label: str, cell: tuple[int, int]) -> bool:
    return cell in STARTING_BOARD[label]


def board_matches_starting_positions(
    board_state: dict[str, tuple[tuple[int, int], ...]],
) -> bool:
    return same_board(board_state, STARTING_BOARD)


def choose_temporary_cell(
    board_state: dict[str, tuple[tuple[int, int], ...]],
) -> tuple[int, int]:
    occupied = set(board_state[HUMAN_LABEL]) | set(board_state[ROBOT_LABEL])
    required = set(STARTING_BOARD[HUMAN_LABEL]) | set(STARTING_BOARD[ROBOT_LABEL])
    for cell in all_cells():
        if cell not in occupied and cell not in required:
            return cell
    for cell in all_cells():
        if cell not in occupied:
            return cell
    raise ValueError("No empty temporary square is available for reset")


def choose_reset_source(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    label: str,
) -> tuple[int, int]:
    for cell in board_state[label]:
        if not is_required_target(label, cell):
            return cell
    raise ValueError(f"No movable {label} is available for reset")


def plan_reset_moves(
    current_board: dict[str, tuple[tuple[int, int], ...]],
) -> list[dict]:
    """Plan deterministic non-colliding moves back to STARTING_BOARD."""
    state = {label: tuple(cells) for label, cells in current_board.items()}
    reset_moves = []

    if len(state[ROBOT_LABEL]) != len(STARTING_BOARD[ROBOT_LABEL]):
        raise ValueError("Expected exactly two green blocks before reset")
    if len(state[HUMAN_LABEL]) != len(STARTING_BOARD[HUMAN_LABEL]):
        raise ValueError("Expected exactly two blue blocks before reset")

    while not board_matches_starting_positions(state):
        moved = False

        # First fill required targets that are already empty.
        for label in RESET_LABEL_ORDER:
            for target in STARTING_BOARD[label]:
                if target in state[label]:
                    continue
                if occupant_at(state, target) is None:
                    start = choose_reset_source(state, label)
                    reset_moves.append({"label": label, "start": start, "target": target})
                    state = apply_robot_move_to_board(state, start, target, label)
                    moved = True
                    break
            if moved:
                break
        if moved:
            continue

        # Then clear wrong-colour blocks from required target squares.
        for label in RESET_LABEL_ORDER:
            for target in STARTING_BOARD[label]:
                occupant = occupant_at(state, target)
                if occupant is not None and occupant != label:
                    temporary = choose_temporary_cell(state)
                    reset_moves.append(
                        {"label": occupant, "start": target, "target": temporary}
                    )
                    state = apply_robot_move_to_board(state, target, temporary, occupant)
                    moved = True
                    break
            if moved:
                break

        if not moved:
            raise ValueError("Could not find a safe reset move")

    return reset_moves


def build_robot_payload(
    calibration: BoardCalibration,
    start: tuple[int, int],
    target: tuple[int, int],
    occupied: set[tuple[int, int]],
    label: str = ROBOT_LABEL,
    graveyard_index: int = 0,
) -> dict:
    is_capture = target in occupied
    payload = calibration.build_move_json(start, target, is_capture, graveyard_index)
    payload.update(
        {
            "object_id": label.replace(" ", "_") + "_1",
            "label": label,
            "from_square": cell_name(start),
            "to_square": cell_name(target),
        }
    )
    return payload


def calibration_is_verified(path: Path) -> bool:
    with path.open("r", encoding="utf-8") as file:
        return json.load(file).get("robot_coordinates_verified") is True


def save_plan(payload: dict, path: Path) -> None:
    with path.open("w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2)
        file.write("\n")
    print(f"[ROBOT] Plan saved: {path.resolve()}")


def print_robot_move(payload: dict) -> None:
    color = str(payload.get("label", ROBOT_LABEL)).replace(" block", "").upper()
    print("\n=== ROBOT MOVE ===")
    print(f"Board: {color} {payload['from_square']} -> {payload['to_square']}")
    if payload.get("is_capture"):
        graveyard = payload["graveyard"]
        print(
            "Capture: target piece will be moved to graveyard "
            f"slot {payload.get('graveyard_index', 0)} "
            f"(X={graveyard['x']:.2f}, Y={graveyard['y']:.2f})"
        )
    print(
        "Robot coordinates:\n"
        f"Start:  X={payload['start']['x']:.2f}, Y={payload['start']['y']:.2f}\n"
        f"Target: X={payload['target']['x']:.2f}, Y={payload['target']['y']:.2f}"
    )


def safety_checks_pass(
    args,
    calibration: BoardCalibration,
    stable_board: dict[str, tuple[tuple[int, int], ...]],
    expected_board: dict[str, tuple[tuple[int, int], ...]],
    start: tuple[int, int],
    target: tuple[int, int],
    label: str = ROBOT_LABEL,
    require_rule: bool = True,
    allow_capture: bool = False,
    limits: dict[str, tuple[int, int | None]] | None = None,
) -> bool:
    print("\nSafety check:")
    ok = True

    valid_counts, count_reason = validate_piece_counts(stable_board, limits)
    if valid_counts:
        print("Piece count: OK")
    else:
        print(f"Piece count: FAILED - {count_reason}")
        ok = False

    if start in stable_board[label]:
        print(f"Start {cell_name(start)}: OK")
    else:
        print(f"Start {cell_name(start)}: FAILED")
        print(f"Camera sees {label}: {format_cells(stable_board[label])}")
        ok = False

    target_occupant = occupant_at(stable_board, target)
    if target_occupant is None or target == start:
        print(f"Target {cell_name(target)}: OK")
    elif allow_capture and target_occupant != label:
        print(f"Target {cell_name(target)}: OK - capture {target_occupant}")
    else:
        print(f"Target {cell_name(target)}: FAILED - occupied")
        ok = False

    if require_rule:
        if follows_movement_rule(label, start, target):
            print("Rule: OK")
        else:
            print("Rule: FAILED")
            ok = False
    else:
        print("Reset move path: OK")

    if same_board(stable_board, expected_board):
        print("Board stable: OK")
    else:
        print("Board stable: FAILED - board changed while planning")
        ok = False

    try:
        calibration.cell_to_robot(start)
        calibration.cell_to_robot(target)
        print("Calibration: OK")
    except Exception as error:
        print(f"Calibration: FAILED - {error}")
        ok = False

    if args.execute and not calibration_is_verified(args.calibration):
        print("Robot coordinate verification: FAILED")
        ok = False
    elif args.execute:
        print("Robot coordinate verification: OK")

    if not ok:
        print("\nSAFETY STOP")
        print("Robot movement cancelled.")
    return ok


def execute_robot_payload(args, payload: dict) -> bool:
    print_robot_move(payload)
    save_plan(payload, args.plan_output)
    label = str(payload.get("label", ROBOT_LABEL))
    if not args.execute:
        print(f"[SIMULATION] Robot move would be: {payload['from_square']} -> {payload['to_square']}")
        print(f"[SIMULATION] Move the {label} manually to continue verification.")
        return True

    print(f"[ROBOT] Executing {payload['from_square']} -> {payload['to_square']}")
    if input("Type MOVE to execute with bots_move.py: ").strip().upper() != "MOVE":
        print("[ROBOT] Move cancelled")
        return False

    dash = motion = None
    try:
        set_wait_scale(args.wait_scale)
        dash, motion = connect_robot(args.speed)
        go_to_start(motion)
        execute_move(dash, motion, payload)
        go_to_start(motion)
    finally:
        if dash is not None:
            dash.close()
        if motion is not None:
            motion.close()
    print("[ROBOT] Robot command finished")
    return True


def verify_robot_move(
    camera,
    calibration: BoardCalibration,
    args,
    planned_board: dict[str, tuple[tuple[int, int], ...]],
    start: tuple[int, int],
    target: tuple[int, int],
    label: str = ROBOT_LABEL,
    state_name: str = VERIFYING_ROBOT_MOVE,
) -> tuple[bool, dict[str, tuple[tuple[int, int], ...]] | None]:
    tracker = StableBoardTracker(args.confirm_frames)
    started = time.monotonic()
    status = f"Verifying {label} {cell_name(start)} -> {cell_name(target)}"
    print(f"\n[VERIFY] {status}")
    while True:
        frame = read_camera_frame(camera)
        latest, detections, board = get_board_state(frame, calibration)
        draw_robot_coordinates(latest, detections, calibration)
        draw_game_overlay(latest, calibration, state_name, status)
        if not args.no_window:
            cv2.imshow("4x4 Camera Robot Game", fit_preview(latest))
            if stop_key_pressed():
                raise KeyboardInterrupt
        if same_board(board, planned_board) and tracker.update(board):
            print(f"[VERIFY] Confirmed: {cell_name(start)} -> {cell_name(target)}")
            return True, board
        if not same_board(board, planned_board):
            tracker.reset()
        if time.monotonic() - started > args.robot_verify_timeout:
            print("\nMOVE VERIFICATION FAILED")
            print(f"Expected: {label} {cell_name(start)} -> {cell_name(target)}")
            print(f"Detected {label}: {format_cells(board[label])}")
            print("Robot will NOT make another move. Please inspect the board.")
            return False, None


def draw_game_overlay(
    image,
    calibration: BoardCalibration,
    state: str,
    status: str,
    human_move: dict | None = None,
    robot_move: tuple[tuple[int, int], tuple[int, int]] | None = None,
) -> None:
    for row in range(GRID_SIZE):
        for column in range(GRID_SIZE):
            cell = (column, row)
            polygon = calibration.cell_polygon(cell)
            cv2.polylines(image, [polygon], True, (255, 255, 255), 2)
            x, y = calibration.board_to_pixel((column + 0.08, row + 0.22))
            cv2.putText(
                image,
                cell_name(cell),
                (x, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.7,
                (255, 255, 255),
                2,
                cv2.LINE_AA,
            )

    lines = [f"STATE: {state}", status]
    if human_move is not None:
        lines.append(
            f"HUMAN: {cell_name(human_move['start'])} -> {cell_name(human_move['target'])}"
        )
    if robot_move is not None:
        lines.append(f"ROBOT: {cell_name(robot_move[0])} -> {cell_name(robot_move[1])}")

    y = 36
    for line in lines[:5]:
        cv2.putText(
            image,
            line,
            (20, y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.85,
            (0, 255, 255),
            3,
            cv2.LINE_AA,
        )
        y += 34


def stop_key_pressed() -> bool:
    key = cv2.waitKey(1) & 0xFF
    return key in (ord("q"), ord("Q"), 27)


class ConsoleCommandReader:
    def __init__(self):
        self.use_msvcrt = os.name == "nt"
        self.buffer = ""
        self.commands = queue.Queue()
        if not self.use_msvcrt:
            self.thread = threading.Thread(target=self._read_loop, daemon=True)
            self.thread.start()

    def _read_loop(self) -> None:
        while True:
            try:
                command = input().strip().lower()
            except EOFError:
                return
            if command:
                self.commands.put(command)

    def get_command(self) -> str | None:
        if self.use_msvcrt:
            import msvcrt

            while msvcrt.kbhit():
                char = msvcrt.getwch()
                if char in ("\r", "\n"):
                    command = self.buffer.strip().lower()
                    self.buffer = ""
                    if command:
                        print()
                        return command
                elif char == "\b":
                    self.buffer = self.buffer[:-1]
                else:
                    self.buffer += char
                    print(char, end="", flush=True)
            return None
        try:
            return self.commands.get_nowait()
        except queue.Empty:
            return None


def detect_and_lock_grid(args, camera, calibration: BoardCalibration) -> None:
    board_frame = read_camera_frame(camera)
    saved_corners = calibration.image_points.copy()
    saved_score = score_4x4_board(board_frame, saved_corners)
    try:
        board_corners, board_score = detect_4x4_board(board_frame)
        corner_drift = float(np.mean(np.linalg.norm(board_corners - saved_corners, axis=1)))
        if saved_score >= 25 and corner_drift > 60:
            board_corners = saved_corners
            board_score = saved_score
            print(
                "[CAMERA] Automatic grid shifted from calibration; "
                f"using saved corners (confidence {board_score:.2f})"
            )
        else:
            calibration.update_image_points(board_corners)
            print(f"[CAMERA] Board detected (confidence {board_score:.2f})")
    except RuntimeError as detection_error:
        board_corners = saved_corners
        board_score = saved_score
        if board_score < 25 and not args.use_saved_grid:
            raise RuntimeError(
                f"{detection_error}; saved board calibration also has low "
                f"confidence ({board_score:.2f})"
            ) from detection_error
        print(
            "[CAMERA] Grid partly covered; using saved camera-board corners "
            f"(confidence {board_score:.2f})"
        )
    cv2.imwrite(str(args.grid_output), draw_detected_board(board_frame, board_corners))
    print(f"[CAMERA] Grid preview saved: {args.grid_output.resolve()}")


def print_coordinate_table(calibration: BoardCalibration) -> None:
    print("\n4x4 calibrated square centres")
    print("Square       Robot X       Robot Y       Robot Z       R")
    for row in range(GRID_SIZE):
        for column in range(GRID_SIZE):
            cell = (column, row)
            coordinate = calibration.cell_to_robot(cell)
            print(
                f"{cell_name(cell):<8} {coordinate['x']:>12.2f} "
                f"{coordinate['y']:>13.2f} "
                f"{coordinate.get('z', calibration.board_z):>13.2f} "
                f"{coordinate['r']:>7.2f}"
            )


def build_robot_plan_to_cell(
    calibration: BoardCalibration,
    positions: dict[str, tuple[int, int]],
    target: tuple[int, int],
    expected_start: tuple[int, int] | None = None,
) -> dict:
    start = positions.get(ROBOT_LABEL)
    if start is None:
        raise ValueError("Green block must be detected on A1-D4 before planning")
    if expected_start is not None and start != expected_start:
        raise ValueError(
            f"Expected green block at {cell_name(expected_start)}, but camera saw "
            f"{cell_name(start)}"
        )
    if start == target:
        raise ValueError(f"Green block is already on {cell_name(target)}")
    is_capture = target in positions.values()
    payload = calibration.build_move_json(start, target, is_capture)
    payload.update(
        {
            "object_id": "green_block_1",
            "from_square": cell_name(start),
            "to_square": cell_name(target),
        }
    )
    return payload


def best_single_positions(
    detections: list[dict],
    calibration: BoardCalibration,
) -> dict[str, tuple[int, int]]:
    best = {}
    for detection in detections:
        label = detection["label"]
        if label not in LABELS:
            continue
        cell = calibration.pixel_to_cell(detection["center"])
        if cell is None:
            continue
        if label not in best or detection["confidence"] > best[label]["confidence"]:
            best[label] = {"cell": cell, "confidence": detection["confidence"]}
    return {label: item["cell"] for label, item in best.items()}


def run_robot_now(args, camera, calibration: BoardCalibration) -> None:
    expected_start = parse_cell_name(args.from_square) if args.from_square else None
    requested_target = parse_cell_name(args.to) if args.to else None
    board, _, detections = capture_stable_board(
        camera,
        calibration,
        args.confirm_frames,
        args.no_window,
        WAITING_FOR_ROBOT,
        "Reading green block position for immediate robot move",
    )
    positions = best_single_positions(detections, calibration)
    if requested_target is None:
        robot_start, robot_target = choose_robot_move(board)
        payload = build_robot_payload(
            calibration, robot_start, robot_target, set(board[HUMAN_LABEL])
        )
    else:
        payload = build_robot_plan_to_cell(
            calibration, positions, requested_target, expected_start
        )
    execute_robot_payload(args, payload)


def print_required_starting_board() -> None:
    print("\nRequired starting board:")
    print(f"Green: {format_cells(STARTING_BOARD[ROBOT_LABEL])}")
    print(f"Blue:  {format_cells(STARTING_BOARD[HUMAN_LABEL])}")


def print_already_correct(board_state: dict[str, tuple[tuple[int, int], ...]]) -> None:
    for label in LABELS:
        color = "GREEN" if label == ROBOT_LABEL else "BLUE"
        for cell in STARTING_BOARD[label]:
            if cell in board_state[label]:
                print(f"{cell_name(cell)} {color.lower()} already correct.")


def run_reset_board(
    args,
    camera,
    calibration: BoardCalibration,
    robot_busy: bool,
) -> tuple[bool, dict[str, tuple[tuple[int, int], ...]] | None]:
    if robot_busy:
        print("[RESET] Robot is busy. Reset cannot start yet.")
        return False, None

    print("\n================================")
    print("RESETTING BOARD")
    print("================================")
    print_required_starting_board()
    print("\nDetecting current board...")
    current_board, _, _ = capture_stable_board(
        camera,
        calibration,
        args.confirm_frames,
        args.no_window,
        RESETTING_BOARD,
        "Detecting current board for reset",
    )
    print_board_state("CURRENT", current_board)
    print_already_correct(current_board)

    try:
        reset_moves = plan_reset_moves(current_board)
    except Exception as error:
        print(f"\nRESET ERROR\n{error}")
        return False, None

    print(f"\nReset moves required: {len(reset_moves)}")
    if not reset_moves:
        final_board = current_board
    else:
        working_board = current_board
        final_board = None
        for index, move in enumerate(reset_moves, start=1):
            label = move["label"]
            start = move["start"]
            target = move["target"]
            color = "GREEN" if label == ROBOT_LABEL else "BLUE"
            print(f"\n[{index}/{len(reset_moves)}]")
            print(f"{color} {cell_name(start)} -> {cell_name(target)}")

            stable_board, _, _ = capture_stable_board(
                camera,
                calibration,
                args.confirm_frames,
                args.no_window,
                RESETTING_BOARD,
                "Checking stable board before reset move",
            )
            if not same_board(stable_board, working_board):
                print("\nRESET ERROR")
                print("Camera board changed before the planned reset move.")
                print_board_state("EXPECTED", working_board)
                print_board_state("DETECTED", stable_board)
                return False, None

            if start not in stable_board[label]:
                print("\nRESET ERROR")
                print(f"Expected {color} at {cell_name(start)}, but camera does not match.")
                return False, None
            if occupant_at(stable_board, target) is not None:
                print("\nRESET ERROR")
                print(f"Target {cell_name(target)} is occupied. Reset stopped.")
                return False, None

            planned_board = apply_robot_move_to_board(working_board, start, target, label)
            payload = build_robot_payload(calibration, start, target, set(), label)
            if not safety_checks_pass(
                args,
                calibration,
                stable_board,
                working_board,
                start,
                target,
                label,
                require_rule=False,
            ):
                return False, None

            robot_busy = True
            try:
                executed = execute_robot_payload(args, payload)
                if not executed:
                    return False, None
            finally:
                robot_busy = False

            verified, verified_board = verify_robot_move(
                camera,
                calibration,
                args,
                planned_board,
                start,
                target,
                label,
                RESETTING_BOARD,
            )
            if not verified:
                print("\nRESET ERROR")
                print(f"Expected: {color} {cell_name(start)} -> {cell_name(target)}")
                print("Camera does not match expected board. Reset stopped.")
                return False, None

            working_board = verified_board
            final_board = verified_board

    print("\nFinal board check...")
    final_board, _, _ = capture_stable_board(
        camera,
        calibration,
        args.confirm_frames,
        args.no_window,
        RESETTING_BOARD,
        "Verifying final reset board",
    )
    if board_matches_starting_positions(final_board):
        print("\n================================")
        print("RESET COMPLETE")
        print("================================")
        print(f"Green = {format_cells(final_board[ROBOT_LABEL])}")
        print(f"Blue = {format_cells(final_board[HUMAN_LABEL])}")
        return True, final_board

    print("\nRESET INCOMPLETE")
    print_board_state("EXPECTED", STARTING_BOARD)
    print_board_state("DETECTED", final_board)
    return False, final_board


def run_self_test() -> None:
    previous = {
        HUMAN_LABEL: ((1, 1), (3, 0)),
        ROBOT_LABEL: ((2, 2),),
    }
    current = {
        HUMAN_LABEL: ((1, 3), (3, 0)),
        ROBOT_LABEL: ((2, 2),),
    }
    move, reason = detect_human_move(previous, current)
    assert reason is None
    assert move["start"] == (1, 1) and move["target"] == (1, 3)
    assert validate_human_move(previous, current, move)[0]
    robot_start, robot_target = choose_robot_move(current)
    assert robot_start == (2, 2)
    assert robot_target == (1, 3)
    planned = apply_robot_move_to_board(current, robot_start, robot_target)
    assert (1, 3) in planned[ROBOT_LABEL]
    assert (1, 3) not in planned[HUMAN_LABEL]
    multi_piece_board = {
        HUMAN_LABEL: ((0, 0), (1, 0), (3, 3)),
        ROBOT_LABEL: ((2, 2), (3, 0)),
    }
    assert validate_piece_counts(multi_piece_board)[0]
    multi_start, multi_target = choose_robot_move(multi_piece_board)
    assert multi_start in multi_piece_board[ROBOT_LABEL]
    assert multi_target not in multi_piece_board[ROBOT_LABEL]
    calibration = BoardCalibration.__new__(BoardCalibration)
    calibration.safe_z = -80.0
    calibration.board_z = -140.0
    calibration.r = 0.0
    calibration.graveyard = {"x": 100.0, "y": 200.0, "r": 5.0, "spacing": 25.0}
    calibration.cell_to_robot = lambda cell: {
        "x": float(cell[0]),
        "y": float(cell[1]),
        "r": 0.0,
    }
    capture_payload = build_robot_payload(
        calibration,
        (2, 2),
        (1, 3),
        {(1, 3)},
        ROBOT_LABEL,
        graveyard_index=1,
    )
    assert capture_payload["is_capture"] is True
    assert capture_payload["graveyard"] == {"x": 125.0, "y": 200.0, "r": 5.0}
    assert capture_payload["graveyard_index"] == 1
    changed_green = {
        HUMAN_LABEL: previous[HUMAN_LABEL],
        ROBOT_LABEL: ((0, 0),),
    }
    assert detect_human_move(previous, changed_green)[1] is not None
    assert plan_reset_moves(STARTING_BOARD) == []
    reset_start = {
        ROBOT_LABEL: ((1, 1), (2, 3)),
        HUMAN_LABEL: ((0, 0), (2, 1)),
    }
    reset_moves = plan_reset_moves(reset_start)
    assert reset_moves == [
        {"label": ROBOT_LABEL, "start": (1, 1), "target": (0, 1)},
        {"label": ROBOT_LABEL, "start": (2, 3), "target": (0, 3)},
        {"label": HUMAN_LABEL, "start": (0, 0), "target": (3, 0)},
        {"label": HUMAN_LABEL, "start": (2, 1), "target": (3, 2)},
    ]
    blocked_start = {
        ROBOT_LABEL: ((2, 2), (0, 3)),
        HUMAN_LABEL: ((0, 1), (3, 0)),
    }
    blocked_moves = plan_reset_moves(blocked_start)
    assert blocked_moves[0]["label"] == HUMAN_LABEL
    assert blocked_moves[0]["start"] == (0, 1)
    assert blocked_moves[0]["target"] == (3, 2)
    assert board_matches_starting_positions(
        apply_robot_move_to_board(
            apply_robot_move_to_board(
                blocked_start,
                blocked_moves[0]["start"],
                blocked_moves[0]["target"],
                blocked_moves[0]["label"],
            ),
            blocked_moves[1]["start"],
            blocked_moves[1]["target"],
            blocked_moves[1]["label"],
        )
    )
    print("Combined workflow self-test passed")


def run_continuous_game(args) -> None:
    state = INITIALIZING
    robot_busy = False
    capture_count = 0
    piece_limits: dict[str, tuple[int, int | None]] = {
        ROBOT_LABEL: (args.min_green_blocks, args.max_green_blocks),
        HUMAN_LABEL: (args.min_blue_blocks, args.max_blue_blocks),
    }
    calibration = BoardCalibration(args.calibration)
    print_coordinate_table(calibration)
    camera = create_camera(
        args.camera_type,
        args.camera_index,
        args.camera_width,
        args.camera_height,
        args.camera_fps,
        args.mvs_device_index,
        args.serial,
    )

    try:
        print("\n================================")
        print("4x4 CAMERA ROBOT GAME")
        print("================================")
        print(f"Simulation: {'OFF' if args.execute else 'ON'}")
        print("\nDetecting board...")
        detect_and_lock_grid(args, camera, calibration)

        if args.robot_now:
            run_robot_now(args, camera, calibration)
            state = STOPPED
            return

        confirmed_board, latest, detections = capture_stable_board(
            camera,
            calibration,
            args.confirm_frames,
            args.no_window,
            INITIALIZING,
            "Detecting initial stable board",
        )
        draw_robot_coordinates(latest, detections, calibration)
        valid_counts, count_reason = validate_piece_counts(confirmed_board, piece_limits)
        if not valid_counts:
            raise RuntimeError(f"Initial board is not usable: {count_reason}")
        print_board_state("INITIAL BOARD", confirmed_board)
        print("[TURN] Human turn. Waiting for movement...")
        print("Type end and press Enter to reset the board and stop.")
        state = WAITING_FOR_HUMAN
        human_tracker = StableBoardTracker(args.confirm_frames)
        command_reader = ConsoleCommandReader()
        pending_human_move = None
        stable_human_board = None

        while True:
            if robot_busy:
                time.sleep(0.05)
                continue

            frame = read_camera_frame(camera)
            latest, detections, board = get_board_state(frame, calibration)
            draw_robot_coordinates(latest, detections, calibration)
            draw_game_overlay(
                latest,
                calibration,
                state,
                "Waiting for blue move" if state == WAITING_FOR_HUMAN else state,
                pending_human_move,
            )

            if not args.no_window:
                cv2.imshow("4x4 Camera Robot Game", fit_preview(latest))
                if stop_key_pressed():
                    state = STOPPED
                    break

            command = command_reader.get_command()
            if command == "end":
                print("\nCommand received: end")
                state = RESETTING_BOARD
                robot_busy = True
                try:
                    run_reset_board(args, camera, calibration, False)
                finally:
                    robot_busy = False
                state = STOPPED
                break
            if command in ("q", "quit", "stop"):
                state = STOPPED
                break

            if state == WAITING_FOR_HUMAN:
                valid_counts, count_reason = validate_piece_counts(board, piece_limits)
                if not valid_counts:
                    log_debug(f"Ignoring unstable/invalid board: {count_reason}")
                    human_tracker.reset()
                    time.sleep(0.02)
                    continue
                if same_board(confirmed_board, board):
                    human_tracker.reset()
                    time.sleep(0.02)
                    continue
                if not human_tracker.update(board):
                    time.sleep(0.02)
                    continue

                move, reason = detect_human_move(confirmed_board, board)
                if reason is not None:
                    print("\nINVALID HUMAN MOVE")
                    print(f"Detected blue: {format_cells(board[HUMAN_LABEL])}")
                    print(f"Detected green: {format_cells(board[ROBOT_LABEL])}")
                    print(f"Reason: {reason}")
                    print("Please correct the board.")
                    human_tracker.reset()
                    continue
                if move is None:
                    continue

                state = HUMAN_MOVE_DETECTED
                allowed, reason = validate_human_move(
                    confirmed_board, board, move, piece_limits
                )
                if not allowed:
                    print("\nINVALID HUMAN MOVE")
                    print(
                        f"Detected: {cell_name(move['start'])} -> "
                        f"{cell_name(move['target'])}"
                    )
                    print(f"Reason: {reason}")
                    print("Please correct the board.")
                    state = WAITING_FOR_HUMAN
                    human_tracker.reset()
                    continue

                pending_human_move = move
                stable_human_board = board
                print(
                    f"\n[HUMAN] Human move detected: "
                    f"{cell_name(move['start'])} -> {cell_name(move['target'])}"
                )
                print("[VALID] Human move accepted")
                state = PLANNING_ROBOT_MOVE

            if state == PLANNING_ROBOT_MOVE:
                print("[AI] Planning robot move...")
                try:
                    robot_start, robot_target = choose_robot_move(stable_human_board)
                    payload = build_robot_payload(
                        calibration,
                        robot_start,
                        robot_target,
                        set(stable_human_board[HUMAN_LABEL]),
                        ROBOT_LABEL,
                        capture_count,
                    )
                    planned_board = apply_robot_move_to_board(
                        stable_human_board, robot_start, robot_target
                    )
                    print(
                        f"[AI] Robot move selected: "
                        f"{cell_name(robot_start)} -> {cell_name(robot_target)}"
                    )
                except Exception as error:
                    print(f"[ERROR] Robot planning failed: {error}")
                    state = ERROR
                    continue
                state = WAITING_FOR_ROBOT

            if state == WAITING_FOR_ROBOT:
                check_board, _, _ = capture_stable_board(
                    camera,
                    calibration,
                    args.confirm_frames,
                    args.no_window,
                    WAITING_FOR_ROBOT,
                    "Rechecking board before robot move",
                )
                if not safety_checks_pass(
                    args,
                    calibration,
                    check_board,
                    stable_human_board,
                    robot_start,
                    robot_target,
                    ROBOT_LABEL,
                    True,
                    payload.get("is_capture", False),
                    piece_limits,
                ):
                    state = ERROR
                    continue

                robot_busy = True
                try:
                    executed = execute_robot_payload(args, payload)
                except Exception as error:
                    print(f"[ERROR] Robot command failed: {error}")
                    executed = False
                finally:
                    robot_busy = False

                if not executed:
                    state = ERROR
                    continue
                if payload.get("is_capture"):
                    capture_count += 1
                state = VERIFYING_ROBOT_MOVE

            if state == VERIFYING_ROBOT_MOVE:
                verified, verified_board = verify_robot_move(
                    camera,
                    calibration,
                    args,
                    planned_board,
                    robot_start,
                    robot_target,
                )
                if not verified:
                    state = ERROR
                    continue

                confirmed_board = verified_board
                pending_human_move = None
                stable_human_board = None
                human_tracker.reset()
                print("\n--------------------------------")
                print("TURN COMPLETE")
                print("--------------------------------")
                print("[TURN] Human turn. Waiting for movement...")
                state = WAITING_FOR_HUMAN

            if state == ERROR:
                print("[ERROR] Game paused. Correct the board, then press X to accept current stable board, or Q/ESC/Ctrl+C to stop.")
                while True:
                    corrected_board, latest, _ = capture_stable_board(
                        camera,
                        calibration,
                        args.confirm_frames,
                        args.no_window,
                        ERROR,
                        "Waiting for correction",
                    )
                    if args.no_window:
                        confirmed_board = corrected_board
                        print_board_state("CORRECTED BOARD", confirmed_board)
                        print("[TURN] Human turn. Waiting for movement...")
                        state = WAITING_FOR_HUMAN
                        human_tracker.reset()
                        break
                    cv2.imshow("4x4 Camera Robot Game", fit_preview(latest))
                    key = cv2.waitKey(0) & 0xFF
                    if key in (ord("q"), ord("Q"), 27):
                        state = STOPPED
                        break
                    if key in (ord("x"), ord("X")):
                        confirmed_board = corrected_board
                        print_board_state("CORRECTED BOARD", confirmed_board)
                        print("[TURN] Human turn. Waiting for movement...")
                        state = WAITING_FOR_HUMAN
                        human_tracker.reset()
                        break
                if state == STOPPED:
                    break
    finally:
        print("\nStopping game...")
        print("Robot execution disabled." if not args.execute else "Robot execution stopped.")
        camera.close()
        cv2.destroyAllWindows()
        print("Game stopped safely.")


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--camera-type",
        choices=("auto", "opencv", "hikrobot"),
        default=config.CAMERA_TYPE,
    )
    parser.add_argument("--camera-index", type=int, default=config.CAMERA_INDEX)
    parser.add_argument("--camera-width", type=int, default=config.CAMERA_WIDTH)
    parser.add_argument("--camera-height", type=int, default=config.CAMERA_HEIGHT)
    parser.add_argument("--camera-fps", type=int, default=config.CAMERA_FPS)
    parser.add_argument("--mvs-device-index", type=int, default=config.MVS_DEVICE_INDEX)
    parser.add_argument(
        "--serial",
        default=config.HIKROBOT_SERIAL,
        help="Optional Hikrobot camera serial. Ignored for OpenCV cameras.",
    )
    parser.add_argument(
        "--calibration", type=Path, default=Path("board_calibration.json")
    )
    parser.add_argument("--confirm-frames", type=int, default=STABLE_FRAMES)
    parser.add_argument("--min-green-blocks", type=int, default=MIN_GREEN_BLOCKS)
    parser.add_argument(
        "--max-green-blocks",
        type=parse_optional_max,
        default=MAX_GREEN_BLOCKS,
        help="Maximum green blocks allowed, or none. Default: none.",
    )
    parser.add_argument("--min-blue-blocks", type=int, default=MIN_BLUE_BLOCKS)
    parser.add_argument(
        "--max-blue-blocks",
        type=parse_optional_max,
        default=MAX_BLUE_BLOCKS,
        help="Maximum blue blocks allowed, or none. Default: none.",
    )
    parser.add_argument(
        "--robot-verify-timeout",
        type=float,
        default=ROBOT_VERIFY_TIMEOUT,
        help=f"Seconds to wait for camera verification. Default: {ROBOT_VERIFY_TIMEOUT}.",
    )
    parser.add_argument(
        "--speed",
        type=int,
        default=DEFAULT_SPEED,
        help=f"Robot SpeedFactor percent, 1-100. Default: {DEFAULT_SPEED}.",
    )
    parser.add_argument(
        "--wait-scale",
        type=float,
        default=DEFAULT_WAIT_SCALE,
        help=(
            "Scale fixed waits between robot commands. "
            f"Default: {DEFAULT_WAIT_SCALE}."
        ),
    )
    parser.add_argument("--plan-output", type=Path, default=Path("planned_robot_move.json"))
    parser.add_argument(
        "--grid-output", type=Path, default=Path("detected_4x4_grid.jpg")
    )
    parser.add_argument("--no-window", action="store_true")
    parser.add_argument(
        "--execute",
        action="store_true",
        default=EXECUTE_ROBOT,
        help="Allow physical MG400 movement. Default follows EXECUTE_ROBOT.",
    )
    parser.add_argument("--robot-now", action="store_true")
    parser.add_argument("--from", dest="from_square", help="Expected green square A1-D4 for --robot-now")
    parser.add_argument("--to", help="Target square A1-D4 for --robot-now")
    parser.add_argument("--use-saved-grid", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args(argv)
    if args.confirm_frames < 2:
        parser.error("--confirm-frames must be at least 2")
    if args.min_green_blocks < 0:
        parser.error("--min-green-blocks must be non-negative")
    if args.min_blue_blocks < 0:
        parser.error("--min-blue-blocks must be non-negative")
    if args.max_green_blocks is not None and args.min_green_blocks > args.max_green_blocks:
        parser.error("--min-green-blocks cannot be greater than --max-green-blocks")
    if args.max_blue_blocks is not None and args.min_blue_blocks > args.max_blue_blocks:
        parser.error("--min-blue-blocks cannot be greater than --max-blue-blocks")
    if args.robot_verify_timeout <= 0:
        parser.error("--robot-verify-timeout must be greater than zero")
    if args.robot_now:
        args.use_saved_grid = True
    if args.self_test:
        run_self_test()
        return
    run_continuous_game(args)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped by user")
