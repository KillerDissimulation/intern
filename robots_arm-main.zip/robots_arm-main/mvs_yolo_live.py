"""MVS camera capture and colour-prompted YOLOE object detection helpers."""

from __future__ import annotations

import os
import sys
import time
from ctypes import POINTER, byref, c_ubyte, cast, memset, sizeof
from pathlib import Path

import cv2
import numpy as np


LABELS = {0: "green block", 1: "blue block"}
COLORS = {0: (0, 190, 0), 1: (255, 90, 0)}
MIN_COLOR_COVERAGE = 0.20
_DLL_DIRECTORIES = []


def _load_mvs_sdk():
    sdk_root = Path(os.environ.get("MVS_SDK_ROOT", r"C:\Program Files (x86)\MVS"))
    runtime = Path(
        os.environ.get(
            "MVS_RUNTIME",
            r"C:\Program Files (x86)\Common Files\MVS\Runtime\Win64_x64",
        )
    )
    python_dir = Path(
        os.environ.get(
            "MVS_PYTHON",
            sdk_root / "Development" / "Samples" / "Python" / "MvImport",
        )
    )
    if not python_dir.exists():
        raise RuntimeError(
            "MVS Python SDK was not found. Install Hikrobot MVS or set MVS_PYTHON."
        )
    if str(python_dir) not in sys.path:
        sys.path.insert(0, str(python_dir))
    if not runtime.exists():
        raise RuntimeError(f"MVS runtime was not found: {runtime}")
    os.environ["PATH"] = str(runtime) + os.pathsep + os.environ.get("PATH", "")
    if hasattr(os, "add_dll_directory"):
        _DLL_DIRECTORIES.append(os.add_dll_directory(str(runtime)))
    import MvCameraControl_class as sdk

    return sdk


def require_ok(code: int, action: str) -> None:
    if code != 0:
        raise RuntimeError(f"{action} failed with MVS error 0x{code & 0xFFFFFFFF:08X}")


def decode_text(value) -> str:
    return bytes(value).split(b"\0", 1)[0].decode("utf-8", errors="replace")


class MVSCamera:
    """Small context-friendly wrapper around the Hikrobot MVS USB camera SDK."""

    def __init__(self, requested_serial: str | None = None):
        self.sdk = _load_mvs_sdk()
        self.camera = None
        self.handle_created = False
        self.opened = False
        self.grabbing = False
        self.model = ""
        self.serial = ""

        sdk = self.sdk
        require_ok(sdk.MvCamera.MV_CC_Initialize(), "Initialize MVS SDK")
        try:
            devices = sdk.MV_CC_DEVICE_INFO_LIST()
            require_ok(
                sdk.MvCamera.MV_CC_EnumDevices(sdk.MV_USB_DEVICE, devices),
                "Enumerate USB3 Vision cameras",
            )
            if devices.nDeviceNum == 0:
                raise RuntimeError("No MVS USB3 Vision camera detected")

            selected = None
            for index in range(devices.nDeviceNum):
                device = cast(
                    devices.pDeviceInfo[index], POINTER(sdk.MV_CC_DEVICE_INFO)
                ).contents
                serial = decode_text(device.SpecialInfo.stUsb3VInfo.chSerialNumber)
                if requested_serial is None or serial == requested_serial:
                    selected = device
                    break
            if selected is None:
                raise RuntimeError(f"MVS camera serial {requested_serial} was not found")

            usb_info = selected.SpecialInfo.stUsb3VInfo
            self.model = decode_text(usb_info.chModelName)
            self.serial = decode_text(usb_info.chSerialNumber)
            self.camera = sdk.MvCamera()
            require_ok(self.camera.MV_CC_CreateHandle(selected), "Create camera handle")
            self.handle_created = True
            open_code = 0
            for attempt in range(3):
                open_code = self.camera.MV_CC_OpenDevice(sdk.MV_ACCESS_Exclusive, 0)
                if open_code == 0:
                    break
                if open_code & 0xFFFFFFFF != 0x80000203 or attempt == 2:
                    require_ok(open_code, "Open camera")
                time.sleep(0.5)
            self.opened = True
            require_ok(
                self.camera.MV_CC_SetEnumValue("TriggerMode", sdk.MV_TRIGGER_MODE_OFF),
                "Disable trigger mode",
            )
            require_ok(self.camera.MV_CC_SetBayerCvtQuality(1), "Set Bayer conversion")
            require_ok(self.camera.MV_CC_StartGrabbing(), "Start acquisition")
            self.grabbing = True
            time.sleep(0.5)
        except Exception:
            self.close()
            raise

    def restart_grabbing(self) -> None:
        if self.camera is None:
            return
        if self.grabbing:
            self.camera.MV_CC_StopGrabbing()
            self.grabbing = False
        require_ok(self.camera.MV_CC_StartGrabbing(), "Restart acquisition")
        self.grabbing = True
        time.sleep(0.5)

    def read(self, timeout_ms: int = 3000, attempts: int = 20):
        sdk = self.sdk
        output = None
        last_code = 0
        restarted = False
        for attempt in range(attempts):
            output = sdk.MV_FRAME_OUT()
            memset(byref(output), 0, sizeof(output))
            last_code = self.camera.MV_CC_GetImageBuffer(output, timeout_ms)
            if last_code == 0:
                break
            if last_code & 0xFFFFFFFF != 0x80000007:
                require_ok(last_code, "Acquire frame")
            if not restarted and attempt + 1 == max(3, attempts // 2):
                self.restart_grabbing()
                restarted = True
        else:
            raise RuntimeError(
                f"Acquire frame after {attempts} attempts failed with MVS error "
                f"0x{last_code & 0xFFFFFFFF:08X}. The camera is connected, but it "
                "is not sending frames. Close MVS Viewer/other camera programs, "
                "check the USB cable, and try again."
            )
        try:
            width = output.stFrameInfo.nWidth
            height = output.stFrameInfo.nHeight
            rgb_size = width * height * 3
            rgb_buffer = (c_ubyte * rgb_size)()

            conversion = sdk.MV_CC_PIXEL_CONVERT_PARAM_EX()
            memset(byref(conversion), 0, sizeof(conversion))
            conversion.nWidth = width
            conversion.nHeight = height
            conversion.pSrcData = output.pBufAddr
            conversion.nSrcDataLen = output.stFrameInfo.nFrameLen
            conversion.enSrcPixelType = output.stFrameInfo.enPixelType
            conversion.enDstPixelType = sdk.PixelType_Gvsp_RGB8_Packed
            conversion.pDstBuffer = rgb_buffer
            conversion.nDstBufferSize = rgb_size
            require_ok(
                self.camera.MV_CC_ConvertPixelTypeEx(conversion),
                "Convert frame to RGB",
            )
            rgb = np.ctypeslib.as_array(rgb_buffer)[: conversion.nDstLen]
            rgb = rgb.reshape(height, width, 3)
            return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
        finally:
            self.camera.MV_CC_FreeImageBuffer(output)

    def close(self) -> None:
        if self.camera is not None:
            if self.grabbing:
                self.camera.MV_CC_StopGrabbing()
                self.grabbing = False
            if self.opened:
                self.camera.MV_CC_CloseDevice()
                self.opened = False
            if self.handle_created:
                self.camera.MV_CC_DestroyHandle()
                self.handle_created = False
        if hasattr(self, "sdk"):
            self.sdk.MvCamera.MV_CC_Finalize()


def color_mask(image, color: str):
    hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    if color == "green":
        return cv2.inRange(hsv, (35, 55, 35), (89, 255, 255))
    if color == "blue":
        return cv2.inRange(hsv, (90, 55, 35), (140, 255, 255))
    raise ValueError(f"Unsupported prompt colour: {color}")


def detect_color_blocks(frame):
    """Detect saturated green and blue blocks directly, without a reference image."""
    output = frame.copy()
    frame_area = frame.shape[0] * frame.shape[1]
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (11, 11))
    detections = []
    for identity, color_name in ((0, "green"), (1, "blue")):
        mask = color_mask(frame, color_name)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if not frame_area * 0.002 <= area <= frame_area * 0.10:
                continue
            x, y, width, height = cv2.boundingRect(contour)
            if width <= 0 or height <= 0:
                continue
            aspect = width / height
            fill = area / (width * height)
            if not 0.55 <= aspect <= 1.80 or fill < 0.45:
                continue
            center = (x + width // 2, y + height // 2)
            hsv_roi = cv2.cvtColor(frame[y:y + height, x:x + width], cv2.COLOR_BGR2HSV)
            useful = (hsv_roi[:, :, 1] > 55) & (hsv_roi[:, :, 2] > 35)
            hue = float(np.median(hsv_roi[:, :, 0][useful])) if np.any(useful) else None
            confidence = min(0.99, 0.55 + 0.45 * fill)
            label = LABELS[identity]
            color = COLORS[identity]
            cv2.rectangle(output, (x, y), (x + width, y + height), color, 4)
            cv2.circle(output, center, 7, (0, 0, 255), -1, cv2.LINE_AA)
            hue_text = "" if hue is None else f" H={hue:.0f}"
            cv2.putText(
                output,
                f"{label} {confidence:.0%}{hue_text} center={center}",
                (x, max(35, y - 12)),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.85,
                color,
                3,
                cv2.LINE_AA,
            )
            detections.append(
                {
                    "label": label,
                    "confidence": confidence,
                    "hue": hue,
                    "color_coverage": fill,
                    "center": center,
                    "box": (x, y, x + width, y + height),
                }
            )
    detections.sort(key=lambda item: item["confidence"], reverse=True)
    return output, detections


def reference_box(reference, color: str) -> list[int]:
    mask = color_mask(reference, color)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        raise RuntimeError(f"No {color} object found in reference image")
    contour = max(contours, key=cv2.contourArea)
    x, y, width, height = cv2.boundingRect(contour)
    if width * height < 100:
        raise RuntimeError(f"The {color} reference object is too small")
    return [x, y, x + width, y + height]


def prepare_yolo(reference, model_path: Path):
    try:
        from ultralytics import YOLOE
        from ultralytics.models.yolo.yoloe import YOLOEVPSegPredictor
    except ImportError as error:
        raise RuntimeError("Install ultralytics to run YOLOE detection") from error

    green_box = reference_box(reference, "green")
    blue_box = reference_box(reference, "blue")
    prompts = {
        "bboxes": np.asarray([green_box, blue_box], dtype=np.float32),
        "cls": np.asarray([0, 1], dtype=np.int32),
    }
    print(
        f"YOLO reference prompts: green={green_box}, "
        f"blue={blue_box}"
    )
    model = YOLOE(str(model_path))
    model.predict(
        reference,
        refer_image=reference,
        visual_prompts=prompts,
        predictor=YOLOEVPSegPredictor,
        conf=0.1,
        imgsz=640,
        verbose=False,
    )
    return model


def measured_color(frame, polygon, box, visual_identity: int):
    x1, y1, x2, y2 = box
    roi = frame[max(0, y1):max(0, y2), max(0, x1):max(0, x2)]
    if roi.size == 0:
        return visual_identity, None, 0.0
    hsv = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1]
    useful = (saturation > 55) & (hsv[:, :, 2] > 35)
    coverage = float(np.mean(useful))
    hue = float(np.median(hsv[:, :, 0][useful])) if np.any(useful) else None
    if hue is None:
        return visual_identity, hue, coverage
    if 35 <= hue < 90:
        return 0, hue, coverage
    if 90 <= hue <= 140:
        return 1, hue, coverage
    return visual_identity, hue, coverage


def annotate(frame, result):
    output = frame.copy()
    detections = []
    if result.boxes is None:
        return output, detections

    polygons = result.masks.xy if result.masks is not None else [None] * len(result.boxes)
    if result.masks is not None:
        mask_layer = output.copy()
        for polygon, class_id, box in zip(
            result.masks.xy, result.boxes.cls, result.boxes.xyxy
        ):
            coordinates = tuple(int(value) for value in box.tolist())
            identity, _, coverage = measured_color(
                frame, polygon, coordinates, int(class_id)
            )
            if coverage >= MIN_COLOR_COVERAGE and len(polygon) >= 3:
                cv2.fillPoly(
                    mask_layer,
                    [np.round(polygon).astype(np.int32)],
                    COLORS.get(identity, (0, 255, 255)),
                )
        output = cv2.addWeighted(mask_layer, 0.25, output, 0.75, 0)

    for box, confidence, class_id, polygon in zip(
        result.boxes.xyxy, result.boxes.conf, result.boxes.cls, polygons
    ):
        visual_identity = int(class_id)
        x1, y1, x2, y2 = [int(value) for value in box.tolist()]
        identity, hue, coverage = measured_color(
            frame, polygon, (x1, y1, x2, y2), visual_identity
        )
        if coverage < MIN_COLOR_COVERAGE:
            continue
        label = LABELS.get(identity, f"object {identity}")
        color = COLORS.get(identity, (0, 255, 255))
        center = ((x1 + x2) // 2, (y1 + y2) // 2)
        cv2.rectangle(output, (x1, y1), (x2, y2), color, 4)
        cv2.circle(output, center, 7, (0, 0, 255), -1, cv2.LINE_AA)
        hue_text = "" if hue is None else f" H={hue:.0f}"
        text = f"{label} {float(confidence):.0%}{hue_text} center={center}"
        cv2.putText(
            output,
            text,
            (x1, max(35, y1 - 12)),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.85,
            color,
            3,
            cv2.LINE_AA,
        )
        detections.append(
            {
                "label": label,
                "confidence": float(confidence),
                "hue": hue,
                "color_coverage": coverage,
                "center": center,
                "box": (x1, y1, x2, y2),
            }
        )
    return output, detections


def fit_preview(image):
    height, width = image.shape[:2]
    scale = min(1280 / width, 800 / height, 1.0)
    return cv2.resize(image, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
