"""Camera-guided MG400 warehouse colour sorter.

The sorter reuses the existing MVS camera, 4x4 board calibration, colour block
detection, planned_robot_move.json format, and bots_move.py robot execution.
Default mode is simulation; pass --execute only after calibration is verified.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import cv2

import config
from camera.camera_factory import create_camera
from combined_grid_robot import (
    DEBUG,
    EXECUTE_ROBOT,
    HUMAN_LABEL,
    ROBOT_LABEL,
    RESETTING_BOARD,
    STABLE_FRAMES,
    StableBoardTracker,
    apply_robot_move_to_board,
    build_robot_payload,
    capture_stable_board,
    cell_name,
    detect_and_lock_grid,
    execute_robot_payload,
    format_cells,
    get_board_state,
    occupant_at,
    parse_cell_name,
    safety_checks_pass,
    same_board,
    verify_robot_move,
)
from mvs_grid_rules_live import BoardCalibration, draw_robot_coordinates
from mvs_yolo_live import fit_preview


SORTING_STATE = "WAREHOUSE_SORTING"
DEFAULT_VERIFY_TIMEOUT = 30.0
DEFAULT_SPEED = 60
DEFAULT_WAIT_SCALE = 0.6
DEFAULT_BINS = {
    ROBOT_LABEL: ("A2", "A4"),
    HUMAN_LABEL: ("D1", "D3"),
}


def parse_bins(text: str) -> tuple[tuple[int, int], ...]:
    cells = [parse_cell_name(part) for part in text.split(",") if part.strip()]
    if not cells:
        raise ValueError("At least one bin square is required")
    if len(set(cells)) != len(cells):
        raise ValueError("Bin squares must not repeat")
    return tuple(cells)


def build_sort_bins(args) -> dict[str, tuple[tuple[int, int], ...]]:
    bins = {
        ROBOT_LABEL: parse_bins(args.green_bins),
        HUMAN_LABEL: parse_bins(args.blue_bins),
    }
    overlap = set(bins[ROBOT_LABEL]) & set(bins[HUMAN_LABEL])
    if overlap:
        names = ", ".join(cell_name(cell) for cell in sorted(overlap))
        raise ValueError(f"Green and blue bins overlap: {names}")
    return bins


def board_matches_bins(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    bins: dict[str, tuple[tuple[int, int], ...]],
) -> bool:
    return all(set(board_state[label]).issubset(set(bins[label])) for label in bins)


def choose_temporary_cell(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    bins: dict[str, tuple[tuple[int, int], ...]],
) -> tuple[int, int]:
    occupied = set(board_state[ROBOT_LABEL]) | set(board_state[HUMAN_LABEL])
    bin_cells = set(bins[ROBOT_LABEL]) | set(bins[HUMAN_LABEL])
    for row in range(4):
        for column in range(4):
            cell = (column, row)
            if cell not in occupied and cell not in bin_cells:
                return cell
    for row in range(4):
        for column in range(4):
            cell = (column, row)
            if cell not in occupied:
                return cell
    raise ValueError("No empty temporary square is available")


def choose_sort_source(
    board_state: dict[str, tuple[tuple[int, int], ...]],
    label: str,
    bins: dict[str, tuple[tuple[int, int], ...]],
) -> tuple[int, int] | None:
    correct_bins = set(bins[label])
    for cell in board_state[label]:
        if cell not in correct_bins:
            return cell
    return None


def plan_sort_moves(
    current_board: dict[str, tuple[tuple[int, int], ...]],
    bins: dict[str, tuple[tuple[int, int], ...]],
) -> list[dict]:
    """Plan deterministic colour sorting moves without stacking blocks."""
    state = {label: tuple(cells) for label, cells in current_board.items()}
    moves = []

    for label in bins:
        if len(state[label]) > len(bins[label]):
            raise ValueError(
                f"More {label} objects were detected than available bin squares"
            )

    while not board_matches_bins(state, bins):
        moved = False

        # Fill empty correct bins first.
        for label in (ROBOT_LABEL, HUMAN_LABEL):
            for target in bins[label]:
                if target in state[label]:
                    continue
                if occupant_at(state, target) is None:
                    start = choose_sort_source(state, label, bins)
                    if start is None:
                        continue
                    moves.append({"label": label, "start": start, "target": target})
                    state = apply_robot_move_to_board(state, start, target, label)
                    moved = True
                    break
            if moved:
                break
        if moved:
            continue

        # Clear wrong-colour objects from bin squares.
        for label in (ROBOT_LABEL, HUMAN_LABEL):
            for target in bins[label]:
                occupant = occupant_at(state, target)
                if occupant is not None and occupant != label:
                    own_empty_bin = next(
                        (
                            cell
                            for cell in bins[occupant]
                            if occupant_at(state, cell) is None
                        ),
                        None,
                    )
                    destination = own_empty_bin or choose_temporary_cell(state, bins)
                    moves.append(
                        {"label": occupant, "start": target, "target": destination}
                    )
                    state = apply_robot_move_to_board(
                        state, target, destination, occupant
                    )
                    moved = True
                    break
            if moved:
                break

        if not moved:
            raise ValueError("Could not find a safe sorting move")

    return moves


def print_bins(bins: dict[str, tuple[tuple[int, int], ...]]) -> None:
    print("\nWarehouse sort bins:")
    print(f"Green -> {format_cells(bins[ROBOT_LABEL])}")
    print(f"Blue  -> {format_cells(bins[HUMAN_LABEL])}")


def draw_sort_overlay(image, calibration: BoardCalibration, bins, status: str) -> None:
    for label, color in ((ROBOT_LABEL, (0, 220, 0)), (HUMAN_LABEL, (255, 120, 0))):
        for cell in bins[label]:
            polygon = calibration.cell_polygon(cell)
            cv2.polylines(image, [polygon], True, color, 5)
            x, y = calibration.board_to_pixel((cell[0] + 0.1, cell[1] + 0.85))
            cv2.putText(
                image,
                "GREEN BIN" if label == ROBOT_LABEL else "BLUE BIN",
                (x, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.55,
                color,
                2,
                cv2.LINE_AA,
            )
    cv2.putText(
        image,
        status,
        (20, 36),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.85,
        (0, 255, 255),
        3,
        cv2.LINE_AA,
    )


def run_warehouse_sorter(args) -> None:
    bins = build_sort_bins(args)
    calibration = BoardCalibration(args.calibration)
    camera = create_camera(
        args.camera_type,
        args.camera_index,
        args.camera_width,
        args.camera_height,
        args.camera_fps,
        args.mvs_device_index,
        args.serial,
    )
    robot_busy = False

    try:
        print("\n================================")
        print("MG400 WAREHOUSE COLOUR SORTER")
        print("================================")
        print(f"Simulation: {'OFF' if args.execute else 'ON'}")
        print_bins(bins)
        detect_and_lock_grid(args, camera, calibration)

        current_board, latest, detections = capture_stable_board(
            camera,
            calibration,
            args.confirm_frames,
            args.no_window,
            SORTING_STATE,
            "Detecting objects for sorting",
        )
        draw_robot_coordinates(latest, detections, calibration)
        print("\nCurrent board:")
        print(f"Green = {format_cells(current_board[ROBOT_LABEL])}")
        print(f"Blue  = {format_cells(current_board[HUMAN_LABEL])}")

        moves = plan_sort_moves(current_board, bins)
        print(f"\nSorting moves required: {len(moves)}")
        if not moves:
            print("SORT COMPLETE")
            return

        working_board = current_board
        for index, move in enumerate(moves, start=1):
            label = move["label"]
            start = move["start"]
            target = move["target"]
            color = "GREEN" if label == ROBOT_LABEL else "BLUE"
            print(f"\n[{index}/{len(moves)}] {color} {cell_name(start)} -> {cell_name(target)}")

            stable_board, latest, detections = capture_stable_board(
                camera,
                calibration,
                args.confirm_frames,
                args.no_window,
                SORTING_STATE,
                "Checking stable board before sort move",
            )
            draw_sort_overlay(latest, calibration, bins, "SORTING")
            if not args.no_window:
                cv2.imshow("MG400 Warehouse Colour Sorter", fit_preview(latest))

            if not same_board(stable_board, working_board):
                print("SORT ERROR: board changed before the planned move.")
                return
            if start not in stable_board[label]:
                print(f"SORT ERROR: expected {color} at {cell_name(start)}.")
                return
            if occupant_at(stable_board, target) is not None:
                print(f"SORT ERROR: target {cell_name(target)} is occupied.")
                return

            planned_board = apply_robot_move_to_board(working_board, start, target, label)
            payload = build_robot_payload(calibration, start, target, set(), label)
            if not safety_checks_pass(
                args,
                calibration,
                stable_board,
                working_board,
                start,
                target,
                label,
                require_rule=False,
            ):
                return

            robot_busy = True
            try:
                if not execute_robot_payload(args, payload):
                    return
            finally:
                robot_busy = False

            verified, verified_board = verify_robot_move(
                camera,
                calibration,
                args,
                planned_board,
                start,
                target,
                label,
                SORTING_STATE,
            )
            if not verified:
                print("SORT ERROR: camera verification failed.")
                return
            working_board = verified_board

        final_board, _, _ = capture_stable_board(
            camera,
            calibration,
            args.confirm_frames,
            args.no_window,
            SORTING_STATE,
            "Final sorting verification",
        )
        if board_matches_bins(final_board, bins):
            print("\n================================")
            print("SORT COMPLETE")
            print("================================")
            print(f"Green = {format_cells(final_board[ROBOT_LABEL])}")
            print(f"Blue  = {format_cells(final_board[HUMAN_LABEL])}")
        else:
            print("\nSORT INCOMPLETE")
            print(f"Expected green bins: {format_cells(bins[ROBOT_LABEL])}")
            print(f"Expected blue bins: {format_cells(bins[HUMAN_LABEL])}")
            print(f"Detected green: {format_cells(final_board[ROBOT_LABEL])}")
            print(f"Detected blue: {format_cells(final_board[HUMAN_LABEL])}")
    finally:
        if robot_busy:
            print("Robot movement was interrupted.")
        camera.close()
        cv2.destroyAllWindows()
        print("Sorter stopped safely.")


def run_self_test() -> None:
    bins = {
        ROBOT_LABEL: ((0, 1), (0, 3)),
        HUMAN_LABEL: ((3, 0), (3, 2)),
    }
    board = {
        ROBOT_LABEL: ((1, 1), (2, 3)),
        HUMAN_LABEL: ((0, 0), (2, 1)),
    }
    assert plan_sort_moves(board, bins) == [
        {"label": ROBOT_LABEL, "start": (1, 1), "target": (0, 1)},
        {"label": ROBOT_LABEL, "start": (2, 3), "target": (0, 3)},
        {"label": HUMAN_LABEL, "start": (0, 0), "target": (3, 0)},
        {"label": HUMAN_LABEL, "start": (2, 1), "target": (3, 2)},
    ]
    blocked = {
        ROBOT_LABEL: ((2, 2), (0, 3)),
        HUMAN_LABEL: ((0, 1), (3, 0)),
    }
    moves = plan_sort_moves(blocked, bins)
    assert moves[0] == {"label": HUMAN_LABEL, "start": (0, 1), "target": (3, 2)}
    print("Warehouse sorter self-test passed")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--camera-type",
        choices=("auto", "opencv", "hikrobot"),
        default=config.CAMERA_TYPE,
    )
    parser.add_argument("--camera-index", type=int, default=config.CAMERA_INDEX)
    parser.add_argument("--camera-width", type=int, default=config.CAMERA_WIDTH)
    parser.add_argument("--camera-height", type=int, default=config.CAMERA_HEIGHT)
    parser.add_argument("--camera-fps", type=int, default=config.CAMERA_FPS)
    parser.add_argument("--mvs-device-index", type=int, default=config.MVS_DEVICE_INDEX)
    parser.add_argument(
        "--serial",
        default=config.HIKROBOT_SERIAL,
        help="Optional Hikrobot camera serial. Ignored for OpenCV cameras.",
    )
    parser.add_argument("--calibration", type=Path, default=Path("board_calibration.json"))
    parser.add_argument("--confirm-frames", type=int, default=STABLE_FRAMES)
    parser.add_argument("--robot-verify-timeout", type=float, default=DEFAULT_VERIFY_TIMEOUT)
    parser.add_argument("--speed", type=int, default=DEFAULT_SPEED)
    parser.add_argument("--wait-scale", type=float, default=DEFAULT_WAIT_SCALE)
    parser.add_argument("--plan-output", type=Path, default=Path("planned_robot_move.json"))
    parser.add_argument("--grid-output", type=Path, default=Path("detected_4x4_grid.jpg"))
    parser.add_argument("--green-bins", default=",".join(DEFAULT_BINS[ROBOT_LABEL]))
    parser.add_argument("--blue-bins", default=",".join(DEFAULT_BINS[HUMAN_LABEL]))
    parser.add_argument("--use-saved-grid", action="store_true")
    parser.add_argument("--no-window", action="store_true")
    parser.add_argument("--execute", action="store_true", default=EXECUTE_ROBOT)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.confirm_frames < 2:
        parser.error("--confirm-frames must be at least 2")
    if args.robot_verify_timeout <= 0:
        parser.error("--robot-verify-timeout must be greater than zero")
    if DEBUG:
        print("[DEBUG] Warehouse sorter debug mode enabled")
    if args.self_test:
        run_self_test()
        return
    run_warehouse_sorter(args)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped by user")
