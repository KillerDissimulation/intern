import asyncio
import argparse
import json

import websockets


async def send_test_move(uri: str, wait_for_reply: bool):
    # Define a test payload (Change 'is_capture' to True to test the graveyard routine!)
    test_payload = {
        "schema_version": 1,
        "type": "move_command",
        "is_capture": False,
        "safe_z": -80.0,
        "board_z": -141.40,
        "start": {
            "x": 250.0,
            "y": -20.0,
            "r": 0.0
        },
        "target": {
            "x": 250.0,
            "y": 40.0,
            "r": 0.0
        },
        "graveyard": {
            "x": 100.0,
            "y": -150.0,
            "r": 0.0
        }
    }

    print(f"Connecting to robot server at {uri}...")
    try:
        async with websockets.connect(uri, open_timeout=5) as websocket:
            print("Sending move payload...")
            await websocket.send(json.dumps(test_payload))
            print("Move JSON sent successfully")
            if wait_for_reply:
                response = await asyncio.wait_for(websocket.recv(), timeout=60)
                print(f"Server response: {response}")
    except ConnectionRefusedError:
        print(f"ERROR: {uri} refused the connection.")
        print("Start the receiver on that computer and confirm port 8765 is LISTENING.")
        return 1
    except TimeoutError:
        print("ERROR: Timed out waiting for the server or its completion reply.")
        return 1
    except OSError as error:
        print(f"ERROR: Could not reach {uri}: {error}")
        return 1
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Send one test robot move as JSON")
    parser.add_argument(
        "--websocket", default="ws://10.75.124.30:8765", help="Robot WebSocket URL"
    )
    parser.add_argument(
        "--no-wait",
        action="store_true",
        help="Exit after sending instead of waiting for a robot reply",
    )
    args = parser.parse_args()
    return asyncio.run(send_test_move(args.websocket, not args.no_wait))


if __name__ == "__main__":
    raise SystemExit(main())
