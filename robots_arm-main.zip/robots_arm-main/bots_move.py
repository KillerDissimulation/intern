import socket
import json
import time
import asyncio
import argparse
from pathlib import Path
import websockets

import config

# --- NETWORK CONFIGURATION ---
ROBOT_IP = "192.168.1.6"
DASHBOARD_PORT = 29999
MOTION_PORT = 30003

# --- HARDCODED SETTINGS ---
START_POS = {"x": 302.797, "y": -97.659, "z": -100, "r": 52.649}
VACUUM_PIN = 2
PUMP_PIN = 1
WAIT_SCALE = 1.0
DEFAULT_SPEED = 100
DEFAULT_WAIT_SCALE = 0.6


def send_command(sock, command):
    sock.send(str.encode(f"{command}\n"))


def set_wait_scale(scale):
    global WAIT_SCALE
    if not 0.2 <= scale <= 2.0:
        raise ValueError("--wait-scale must be between 0.2 and 2.0")
    WAIT_SCALE = scale


def robot_wait(seconds):
    time.sleep(max(0.15, seconds * WAIT_SCALE))


def configure_speed(dash, speed):
    if speed is None:
        return
    if not 1 <= speed <= 100:
        raise ValueError("--speed must be between 1 and 100")
    print(f"Setting robot speed factor to {speed}%")
    send_command(dash, f"SpeedFactor({speed})")
    robot_wait(0.3)


def require_number(data, path):
    value = data
    for part in path:
        value = value[part]
    if not isinstance(value, (int, float)):
        raise ValueError(f"{'.'.join(path)} must be a number")
    return float(value)


def validate_move_command(data):
    if not isinstance(data, dict):
        raise ValueError("Move command must be a JSON object")
    if data.get("type") not in (None, "move_command"):
        raise ValueError(f"Unsupported message type: {data.get('type')}")

    for path in (
        ("safe_z",),
        ("board_z",),
        ("start", "x"),
        ("start", "y"),
        ("start", "r"),
        ("target", "x"),
        ("target", "y"),
        ("target", "r"),
    ):
        require_number(data, path)

    if "z" in data["start"]:
        require_number(data, ("start", "z"))
    if "z" in data["target"]:
        require_number(data, ("target", "z"))
    if data.get("is_capture", False):
        for path in (("graveyard", "x"), ("graveyard", "y"), ("graveyard", "r")):
            require_number(data, path)
    return data


def describe_move(data):
    start = data.get("from_square")
    target = data.get("to_square")
    if start and target:
        return f"{start} -> {target}"
    return (
        f"X={data['start']['x']:.2f}, Y={data['start']['y']:.2f} -> "
        f"X={data['target']['x']:.2f}, Y={data['target']['y']:.2f}"
    )


def connect_robot(speed=None):
    print("Connecting to physical robot...")
    dash = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    dash.settimeout(10)
    dash.connect((ROBOT_IP, DASHBOARD_PORT))
    motion = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    motion.settimeout(10)
    motion.connect((ROBOT_IP, MOTION_PORT))

    send_command(dash, "EnableRobot()")
    time.sleep(2)
    configure_speed(dash, speed)
    return dash, motion


def go_to_start(motion):
    print("Moving to Start Position...")
    send_command(
        motion,
        f"MovJ({START_POS['x']}, {START_POS['y']}, {START_POS['z']}, {START_POS['r']})",
    )
    robot_wait(2)


def execute_move(dash, motion, data):
    validate_move_command(data)
    safe_z = data['safe_z']
    board_z = data['board_z']
    is_capture = data.get('is_capture', False)

    item_x, item_y, item_r = data['start']['x'], data['start']['y'], data['start']['r']
    target_x, target_y, target_r = data['target']['x'], data['target']['y'], data['target']['r']
    item_z = data['start'].get('z', board_z)
    target_z = data['target'].get('z', board_z)

    # --- STEP A: CAPTURE LOGIC ---
    if is_capture:
        print("Capture detected! Clearing enemy piece to graveyard...")
        gy_x = data['graveyard']['x']
        gy_y = data['graveyard']['y']
        gy_r = data['graveyard']['r']

        send_command(motion, f"MovJ({target_x}, {target_y}, {safe_z}, {target_r})")
        robot_wait(2)
        send_command(motion, f"MovJ({target_x}, {target_y}, {target_z}, {target_r})")
        robot_wait(1)
        send_command(dash, f"DO({VACUUM_PIN}, 1)")
        robot_wait(0.5)
        send_command(motion, f"MovJ({target_x}, {target_y}, {safe_z}, {target_r})")
        robot_wait(1.5)
        send_command(motion, f"MovJ({gy_x}, {gy_y}, {safe_z}, {gy_r})")
        robot_wait(2)
        send_command(motion, f"MovJ({gy_x}, {gy_y}, {board_z}, {gy_r})")
        robot_wait(1)
        send_command(dash, f"DO({VACUUM_PIN}, 0)")
        send_command(dash, f"DO({PUMP_PIN}, 1)")
        robot_wait(0.5)
        send_command(dash, f"DO({PUMP_PIN}, 0)")
        send_command(motion, f"MovJ({gy_x}, {gy_y}, {safe_z}, {gy_r})")
        robot_wait(1.5)

    # --- STEP B: STANDARD MOVE ---
    print(f"Executing main move: {describe_move(data)}")
    send_command(motion, f"MovJ({item_x}, {item_y}, {safe_z}, {item_r})")
    robot_wait(2)
    send_command(motion, f"MovJ({item_x}, {item_y}, {item_z}, {item_r})")
    robot_wait(1)
    send_command(dash, f"DO({VACUUM_PIN}, 1)")
    robot_wait(0.5)
    send_command(motion, f"MovJ({item_x}, {item_y}, {safe_z}, {item_r})")
    robot_wait(1.5)
    send_command(motion, f"MovJ({target_x}, {target_y}, {safe_z}, {target_r})")
    robot_wait(2)
    send_command(motion, f"MovJ({target_x}, {target_y}, {target_z}, {target_r})")
    robot_wait(1)
    send_command(dash, f"DO({VACUUM_PIN}, 0)")
    send_command(dash, f"DO({PUMP_PIN}, 1)")
    robot_wait(0.5)
    send_command(dash, f"DO({PUMP_PIN}, 0)")
    send_command(motion, f"MovJ({target_x}, {target_y}, {safe_z}, {target_r})")
    robot_wait(1.5)


# Global hardware handles
dash = None
motion = None


async def handle_client(websocket):
    global dash, motion
    print(f"\n[Client Connected from {websocket.remote_address}]")
    try:
        async for message in websocket:
            print("--- New Move Received via WebSocket ---")
            try:
                move_data = json.loads(message)
                if move_data.get("type") == "object_detection":
                    print(
                        f"Camera frame {move_data.get('frame_id')} received: "
                        f"{move_data.get('object_count', 0)} object(s)"
                    )
                    continue
                execute_move(dash, motion, move_data)
                go_to_start(motion)
                await websocket.send("Move completed successfully")
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as error:
                print(f"Error: Invalid JSON message: {error}")
                await websocket.send("Invalid JSON message")
    except websockets.exceptions.ConnectionClosed:
        print("[Client Disconnected]")


async def main(host="0.0.0.0", port=8765, speed=None, wait_scale=1.0):
    global dash, motion
    set_wait_scale(wait_scale)
    dash, motion = connect_robot(speed)
    go_to_start(motion)

    # Start the WebSocket Server on port 8765, listening to any incoming computer network connection
    async with websockets.serve(handle_client, host, port):
        print(f"WebSocket Server is running on ws://{host}:{port} ... Ready for camera moves!")
        await asyncio.Future()  # Keep server running forever


def run_move_json(args):
    set_wait_scale(args.wait_scale)
    with args.move_json.open("r", encoding="utf-8") as file:
        payload = json.load(file)
    validate_move_command(payload)
    print("Move JSON loaded:")
    print(json.dumps(payload, indent=2))
    if not args.execute:
        print("DRY RUN: robot was not moved. Add --execute to run this JSON.")
        return
    if input(f"Type MOVE to execute {describe_move(payload)}: ").strip().upper() != "MOVE":
        print("Robot move cancelled")
        return

    dash_handle = motion_handle = None
    try:
        dash_handle, motion_handle = connect_robot(args.speed)
        go_to_start(motion_handle)
        execute_move(dash_handle, motion_handle, payload)
        go_to_start(motion_handle)
    finally:
        if dash_handle is not None:
            dash_handle.close()
        if motion_handle is not None:
            motion_handle.close()


def run_camera_workflow(args):
    from combined_grid_robot import main as camera_main

    camera_args = [
        "--camera-type",
        args.camera_type,
        "--camera-index",
        str(args.camera_index),
        "--camera-width",
        str(args.camera_width),
        "--camera-height",
        str(args.camera_height),
        "--camera-fps",
        str(args.camera_fps),
        "--mvs-device-index",
        str(args.mvs_device_index),
        "--serial",
        args.serial or "",
        "--calibration",
        str(args.calibration),
        "--confirm-frames",
        str(args.confirm_frames),
        "--plan-output",
        str(args.plan_output),
        "--grid-output",
        str(args.grid_output),
    ]
    if args.no_window:
        camera_args.append("--no-window")
    if args.robot_now:
        camera_args.append("--robot-now")
    if args.from_square:
        camera_args.extend(["--from", args.from_square])
    if args.to:
        camera_args.extend(["--to", args.to])
    if args.use_saved_grid:
        camera_args.append("--use-saved-grid")
    if args.speed is not None:
        camera_args.extend(["--speed", str(args.speed)])
    if args.wait_scale != 1.0:
        camera_args.extend(["--wait-scale", str(args.wait_scale)])
    if args.execute:
        camera_args.append("--execute")
    camera_main(camera_args)


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Move the MG400 from JSON commands, or run the camera-to-robot "
            "A1-D4 workflow."
        )
    )
    parser.add_argument(
        "--camera",
        action="store_true",
        help="Read A1-D4 from the camera and send the planned move to the robot arm",
    )
    parser.add_argument("--execute", action="store_true", help="Allow the camera workflow to move the robot")
    parser.add_argument(
        "--robot-now",
        action="store_true",
        help="Move the green block immediately after the camera reads its A1-D4 square",
    )
    parser.add_argument(
        "--from",
        dest="from_square",
        help="Expected green square A1-D4 for --camera --robot-now",
    )
    parser.add_argument("--to", help="Target square A1-D4 for --camera --robot-now")
    parser.add_argument(
        "--use-saved-grid",
        action="store_true",
        help="Use saved camera-board corners even when grid lines are covered",
    )
    parser.add_argument(
        "--move-json",
        type=Path,
        help="Load and optionally execute one saved move JSON file",
    )
    parser.add_argument(
        "--camera-type",
        choices=("auto", "opencv", "hikrobot"),
        default=config.CAMERA_TYPE,
    )
    parser.add_argument("--camera-index", type=int, default=config.CAMERA_INDEX)
    parser.add_argument("--camera-width", type=int, default=config.CAMERA_WIDTH)
    parser.add_argument("--camera-height", type=int, default=config.CAMERA_HEIGHT)
    parser.add_argument("--camera-fps", type=int, default=config.CAMERA_FPS)
    parser.add_argument("--mvs-device-index", type=int, default=config.MVS_DEVICE_INDEX)
    parser.add_argument("--serial", default=config.HIKROBOT_SERIAL)
    parser.add_argument("--calibration", type=Path, default=Path("board_calibration.json"))
    parser.add_argument("--confirm-frames", type=int, default=3)
    parser.add_argument(
        "--speed",
        type=int,
        default=DEFAULT_SPEED,
        help=f"Robot SpeedFactor percent, 1-100. Default: {DEFAULT_SPEED}.",
    )
    parser.add_argument(
        "--wait-scale",
        type=float,
        default=DEFAULT_WAIT_SCALE,
        help=(
            "Scale fixed waits between robot commands. "
            f"Default: {DEFAULT_WAIT_SCALE}."
        ),
    )
    parser.add_argument("--plan-output", type=Path, default=Path("planned_robot_move.json"))
    parser.add_argument("--grid-output", type=Path, default=Path("detected_4x4_grid.jpg"))
    parser.add_argument("--no-window", action="store_true")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=8765)
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    try:
        if args.move_json:
            run_move_json(args)
        elif args.camera:
            run_camera_workflow(args)
        else:
            asyncio.run(main(args.host, args.port, args.speed, args.wait_scale))
    except KeyboardInterrupt:
        print("\nProgram stopped by user.")
        if dash:
            dash.close()
        if motion:
            motion.close()
