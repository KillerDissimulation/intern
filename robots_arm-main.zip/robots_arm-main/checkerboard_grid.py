"""Detect the outer corners of a partially occluded 4x4 black/white grid."""

from __future__ import annotations

from itertools import combinations

import cv2
import numpy as np


GRID_SIZE = 4


def _cluster_lines(lines: list[tuple[float, float, float]], threshold: float = 28.0):
    """Cluster (position, slope, weight) lines at the image centre."""
    clusters = []
    for position, slope, weight in sorted(lines):
        if clusters and position - clusters[-1]["position"] <= threshold:
            cluster = clusters[-1]
            total = cluster["weight"] + weight
            cluster["position"] = (
                cluster["position"] * cluster["weight"] + position * weight
            ) / total
            cluster["slope"] = (
                cluster["slope"] * cluster["weight"] + slope * weight
            ) / total
            cluster["weight"] = total
        else:
            clusters.append(
                {"position": position, "slope": slope, "weight": weight}
            )
    return clusters


def _regular_sequences(clusters: list[dict], image_extent: int):
    sequences = []
    for count in (5, 4):
        for selected in combinations(clusters, count):
            positions = np.asarray([item["position"] for item in selected])
            indices = np.arange(count, dtype=np.float64)
            step, start = np.polyfit(indices, positions, 1)
            if not image_extent * 0.08 <= step <= image_extent * 0.35:
                continue
            fitted = start + step * indices
            error = float(np.sqrt(np.mean((positions - fitted) ** 2)) / step)
            if error > 0.10:
                continue
            strength = sum(item["weight"] for item in selected) / image_extent
            sequences.append((error - min(strength, 10) * 0.002, selected))
    sequences.sort(key=lambda item: item[0])
    return [selected for _, selected in sequences[:12]]


def _boundary_options(sequence: tuple[dict, ...], centre: float):
    average_slope = float(np.mean([item["slope"] for item in sequence]))
    lines = []
    for item in sequence:
        # line is represented by its position at centre and its slope.
        intercept = item["position"] - item["slope"] * centre
        lines.append((item["slope"], intercept))
    if len(lines) == 5:
        return [lines]

    positions = [item["position"] for item in sequence]
    spacing = float(np.median(np.diff(positions)))
    before_position = positions[0] - spacing
    after_position = positions[-1] + spacing
    before = (average_slope, before_position - average_slope * centre)
    after = (average_slope, after_position - average_slope * centre)
    return [[before, *lines], [*lines, after]]


def _intersection(horizontal, vertical):
    # horizontal: y = mh*x + bh; vertical: x = mv*y + bv
    mh, bh = horizontal
    mv, bv = vertical
    denominator = 1.0 - mv * mh
    if abs(denominator) < 1e-6:
        return None
    x = (mv * bh + bv) / denominator
    y = mh * x + bh
    return np.asarray([x, y], dtype=np.float32)


def _corners(horizontal_lines, vertical_lines):
    points = [
        _intersection(horizontal_lines[0], vertical_lines[0]),
        _intersection(horizontal_lines[0], vertical_lines[-1]),
        _intersection(horizontal_lines[-1], vertical_lines[-1]),
        _intersection(horizontal_lines[-1], vertical_lines[0]),
    ]
    if any(point is None for point in points):
        return None
    return np.asarray(points, dtype=np.float32)


def _checker_score(gray, corners):
    destination = np.asarray(
        [[0, 0], [400, 0], [400, 400], [0, 400]], dtype=np.float32
    )
    matrix = cv2.getPerspectiveTransform(corners, destination)
    warped = cv2.warpPerspective(gray, matrix, (400, 400))
    means = np.zeros((GRID_SIZE, GRID_SIZE), dtype=np.float32)
    for row in range(GRID_SIZE):
        for column in range(GRID_SIZE):
            y1, y2 = row * 100 + 25, row * 100 + 75
            x1, x2 = column * 100 + 25, column * 100 + 75
            means[row, column] = float(np.mean(warped[y1:y2, x1:x2]))
    even = means[(np.indices(means.shape).sum(axis=0) % 2) == 0]
    odd = means[(np.indices(means.shape).sum(axis=0) % 2) == 1]
    contrast = abs(float(np.mean(even) - np.mean(odd)))
    consistency_penalty = 0.15 * (float(np.std(even)) + float(np.std(odd)))
    return contrast - consistency_penalty, means


def score_4x4_board(image, corners) -> float:
    """Score saved board corners against the visible alternating pattern."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    score, _ = _checker_score(gray, np.asarray(corners, dtype=np.float32))
    return round(float(score), 2)


def detect_4x4_board(image) -> tuple[np.ndarray, float]:
    """Return TL, TR, BR, BL grid corners and checker-pattern confidence."""
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(gray, 35, 110)
    raw_lines = cv2.HoughLinesP(
        edges,
        1,
        np.pi / 360,
        threshold=90,
        minLineLength=min(image.shape[:2]) * 0.14,
        maxLineGap=90,
    )
    if raw_lines is None:
        raise RuntimeError("No grid lines were detected")

    height, width = image.shape[:2]
    horizontal = []
    vertical = []
    for raw in raw_lines:
        x1, y1, x2, y2 = (float(value) for value in raw.reshape(4))
        dx, dy = x2 - x1, y2 - y1
        length = float(np.hypot(dx, dy))
        angle = abs(float(np.degrees(np.arctan2(dy, dx))))
        if angle <= 25 and abs(dx) > 1:
            slope = dy / dx
            intercept = y1 - slope * x1
            position = slope * (width / 2) + intercept
            horizontal.append((position, slope, length))
        elif angle >= 65 and abs(dy) > 1:
            slope = dx / dy
            intercept = x1 - slope * y1
            position = slope * (height / 2) + intercept
            vertical.append((position, slope, length))

    horizontal_clusters = _cluster_lines(horizontal)
    vertical_clusters = _cluster_lines(vertical)
    horizontal_sequences = _regular_sequences(horizontal_clusters, height)
    vertical_sequences = _regular_sequences(vertical_clusters, width)
    if not horizontal_sequences or not vertical_sequences:
        raise RuntimeError("Could not find four evenly spaced grid rows and columns")

    best = None
    for horizontal_sequence in horizontal_sequences:
        for horizontal_boundaries in _boundary_options(
            horizontal_sequence, width / 2
        ):
            for vertical_sequence in vertical_sequences:
                for vertical_boundaries in _boundary_options(
                    vertical_sequence, height / 2
                ):
                    corners = _corners(horizontal_boundaries, vertical_boundaries)
                    if corners is None:
                        continue
                    if (
                        np.any(corners[:, 0] < -0.05 * width)
                        or np.any(corners[:, 0] > 1.05 * width)
                        or np.any(corners[:, 1] < -0.05 * height)
                        or np.any(corners[:, 1] > 1.05 * height)
                    ):
                        continue
                    area = abs(float(cv2.contourArea(corners)))
                    if area < width * height * 0.08:
                        continue
                    score, _ = _checker_score(gray, corners)
                    if best is None or score > best[0]:
                        best = (score, corners)
    if best is None or best[0] < 25:
        score = None if best is None else round(best[0], 2)
        raise RuntimeError(f"Black/white 4x4 grid confidence is too low: {score}")
    return best[1], round(float(best[0]), 2)


def draw_detected_board(image, corners, color=(0, 255, 255)):
    output = image.copy()
    cv2.polylines(output, [np.round(corners).astype(np.int32)], True, color, 5)
    return output
