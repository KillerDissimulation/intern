"""Vision helpers for DOBOT MG400 tabletop tasks."""

