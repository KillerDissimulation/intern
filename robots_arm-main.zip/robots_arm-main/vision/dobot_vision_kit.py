"""OpenCV detectors for the DOBOT MG400 Vision Kit tabletop pieces."""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class Detection:
    label: str
    center: tuple[int, int]
    bbox: tuple[int, int, int, int]
    angle: float = 0.0
    area: float = 0.0

    def as_dict(self) -> dict:
        x, y, width, height = self.bbox
        return {
            "label": self.label,
            "center": self.center,
            "bbox": {
                "x": x,
                "y": y,
                "width": width,
                "height": height,
            },
            "angle": round(self.angle, 2),
            "area": round(self.area, 1),
        }


def _clean_mask(mask: np.ndarray, kernel_size: int = 7) -> np.ndarray:
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_size, kernel_size))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)


def color_mask(frame: np.ndarray, color: str) -> np.ndarray:
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    if color == "green":
        return cv2.inRange(hsv, (35, 55, 35), (89, 255, 255))
    if color == "blue":
        return cv2.inRange(hsv, (90, 55, 35), (140, 255, 255))
    raise ValueError(f"Unsupported color: {color}")


def detect_color_cubes(frame: np.ndarray) -> list[Detection]:
    frame_height, frame_width = frame.shape[:2]
    frame_area = frame_height * frame_width
    detections: list[Detection] = []

    for color in ("green", "blue"):
        mask = _clean_mask(color_mask(frame, color), 9)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            area = float(cv2.contourArea(contour))
            if not frame_area * 0.004 <= area <= frame_area * 0.12:
                continue

            x, y, width, height = cv2.boundingRect(contour)
            if width <= 0 or height <= 0:
                continue
            if _touches_image_edge(x, y, width, height, frame_width, frame_height):
                continue

            aspect = width / height
            fill = area / float(width * height)
            if not 0.45 <= aspect <= 1.85 or fill < 0.40:
                continue

            rect = cv2.minAreaRect(contour)
            center = (int(rect[0][0]), int(rect[0][1]))
            detections.append(
                Detection(
                    label=f"{color} cube",
                    center=center,
                    bbox=(x, y, width, height),
                    angle=float(rect[2]),
                    area=area,
                )
            )

    return detections


def white_mask(frame: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (0, 0, 135), (179, 80, 255))
    return _clean_mask(mask, 5)


def detect_white_kit_parts(frame: np.ndarray) -> list[Detection]:
    frame_height, frame_width = frame.shape[:2]
    frame_area = frame_height * frame_width
    mask = white_mask(frame)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    detections: list[Detection] = []

    for contour in contours:
        area = float(cv2.contourArea(contour))
        if not frame_area * 0.0008 <= area <= frame_area * 0.18:
            continue

        x, y, width, height = cv2.boundingRect(contour)
        if width <= 0 or height <= 0:
            continue
        if _touches_image_edge(x, y, width, height, frame_width, frame_height):
            continue

        rect_area = float(width * height)
        fill = area / rect_area
        aspect = max(width, height) / max(1, min(width, height))
        if fill < 0.22 or aspect > 5.5:
            continue

        rect = cv2.minAreaRect(contour)
        center = (int(rect[0][0]), int(rect[0][1]))
        is_tray = area > frame_area * 0.018 and width > 170 and height > 170 and y > frame_height * 0.28
        label = "match tray" if is_tray else "white tile"
        if label == "white tile" and y > frame_height * 0.72:
            continue
        detections.append(
            Detection(
                label=label,
                center=center,
                bbox=(x, y, width, height),
                angle=float(rect[2]),
                area=area,
            )
        )

    return detections


def _touches_image_edge(
    x: int,
    y: int,
    width: int,
    height: int,
    frame_width: int,
    frame_height: int,
    margin: int = 18,
) -> bool:
    return (
        x <= margin
        or y <= margin
        or x + width >= frame_width - margin
        or y + height >= frame_height - margin
    )


def detect_vision_kit_scene(frame: np.ndarray) -> list[Detection]:
    detections = detect_white_kit_parts(frame)
    detections.extend(detect_color_cubes(frame))
    return sorted(detections, key=lambda item: (item.label, item.center[1], item.center[0]))


def draw_detections(frame: np.ndarray, detections: list[Detection]) -> np.ndarray:
    output = frame.copy()
    palette = {
        "green cube": (0, 180, 0),
        "blue cube": (255, 90, 0),
        "white tile": (40, 180, 255),
        "match tray": (0, 0, 255),
    }

    for detection in detections:
        x, y, width, height = detection.bbox
        color = palette.get(detection.label, (255, 255, 255))
        cv2.rectangle(output, (x, y), (x + width, y + height), color, 3)
        cv2.circle(output, detection.center, 5, color, -1, cv2.LINE_AA)
        label = f"{detection.label} {detection.center}"
        text_y = max(24, y - 8)
        cv2.putText(
            output,
            label,
            (x, text_y),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.62,
            color,
            2,
            cv2.LINE_AA,
        )

    return output
