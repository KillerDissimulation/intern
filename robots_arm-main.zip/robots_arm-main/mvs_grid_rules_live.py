"""Live 4x4 MVS/YOLO block game with human and robot movement rules."""

from __future__ import annotations

import argparse
import asyncio
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import cv2
import numpy as np
import websockets

import config
from camera.camera_factory import create_camera
from mvs_yolo_live import annotate, fit_preview, measured_color, prepare_yolo


GRID_SIZE = 4
OWNER = {
    "blue block": "HUMAN",
    "green block": "ROBOT",
}


def read_camera_frame(camera):
    success, frame = camera.read()
    if not success or frame is None:
        raise RuntimeError("Camera frame was not available")
    return frame


class BoardCalibration:
    """Convert camera pixels and grid cells into MG400 X/Y coordinates."""

    def __init__(self, path: Path):
        with path.open("r", encoding="utf-8") as file:
            data = json.load(file)

        image_points = np.asarray(data["image_points"], dtype=np.float32)
        robot_grid = data.get("robot_grid")
        robot_points = np.asarray(data["robot_points"], dtype=np.float32)
        if image_points.shape != (4, 2) or robot_points.shape != (4, 2):
            raise ValueError(
                "image_points and robot_points must each contain four [x,y] points"
            )
        if not np.isfinite(image_points).all() or not np.isfinite(robot_points).all():
            raise ValueError(
                "Replace every null in board_calibration.json with measured values"
            )

        # Point order: top-left, top-right, bottom-right, bottom-left.
        board_points = np.asarray(
            [[0, 0], [GRID_SIZE, 0], [GRID_SIZE, GRID_SIZE], [0, GRID_SIZE]],
            dtype=np.float32,
        )
        self.board_points = board_points
        self.update_image_points(image_points)
        self.board_to_robot = cv2.getPerspectiveTransform(board_points, robot_points)
        self.robot_grid = None
        if robot_grid is not None:
            anchor_name = str(robot_grid["anchor_cell"]).strip().upper()
            if len(anchor_name) != 2 or anchor_name[0] not in "ABCD" or anchor_name[1] not in "1234":
                raise ValueError("robot_grid.anchor_cell must be A1 through D4")
            anchor = np.asarray(robot_grid["anchor"], dtype=float)
            column_step = np.asarray(robot_grid["column_step"], dtype=float)
            row_step = np.asarray(robot_grid["row_step"], dtype=float)
            if anchor.shape != (3,) or column_step.shape != (3,) or row_step.shape != (3,):
                raise ValueError("robot_grid anchor and steps must each be [x,y,z]")
            if not all(np.isfinite(value).all() for value in (anchor, column_step, row_step)):
                raise ValueError("robot_grid contains a non-finite coordinate")
            self.robot_grid = {
                "anchor_cell": (ord(anchor_name[0]) - ord("A"), int(anchor_name[1]) - 1),
                "anchor": anchor,
                "column_step": column_step,
                "row_step": row_step,
            }
        self.safe_z = float(data["safe_z"])
        self.board_z = float(data["board_z"])
        self.r = float(data.get("r", 0.0))
        self.graveyard = data.get("graveyard")

    def graveyard_slot(self, index: int) -> dict[str, float]:
        if self.graveyard is None:
            raise ValueError("A capture requires graveyard in the calibration file")
        if index < 0:
            raise ValueError("graveyard index must be non-negative")
        spacing = float(self.graveyard.get("spacing", 25.0))
        x_offset, y_offset = graveyard_offset(index, spacing)
        return {
            "x": float(self.graveyard["x"]) + x_offset,
            "y": float(self.graveyard["y"]) + y_offset,
            "r": float(self.graveyard.get("r", self.r)),
        }

    def update_image_points(self, image_points) -> None:
        """Replace camera-side calibration while preserving robot coordinates."""
        image_points = np.asarray(image_points, dtype=np.float32)
        if image_points.shape != (4, 2):
            raise ValueError("Detected image points must contain TL, TR, BR, BL")
        self.image_points = image_points.copy()
        self.image_to_board = cv2.getPerspectiveTransform(
            image_points, self.board_points
        )
        self.board_to_image = cv2.getPerspectiveTransform(
            self.board_points, image_points
        )

    @staticmethod
    def _transform(point: tuple[float, float], matrix) -> tuple[float, float]:
        source = np.asarray([[[point[0], point[1]]]], dtype=np.float32)
        result = cv2.perspectiveTransform(source, matrix)[0, 0]
        return float(result[0]), float(result[1])

    def pixel_to_cell(self, center: tuple[int, int]) -> tuple[int, int] | None:
        board_x, board_y = self.pixel_to_board(center)
        if not (0 <= board_x < GRID_SIZE and 0 <= board_y < GRID_SIZE):
            return None
        return int(board_x), int(board_y)

    def pixel_to_board(self, center: tuple[int, int]) -> tuple[float, float]:
        return self._transform(center, self.image_to_board)

    def pixel_to_robot(self, center: tuple[int, int]) -> dict[str, float]:
        board_point = self.pixel_to_board(center)
        if getattr(self, "robot_grid", None) is not None:
            return self._board_position_to_robot(board_point)
        x, y = self._transform(board_point, self.board_to_robot)
        return {"x": round(x, 2), "y": round(y, 2), "r": self.r}

    def _board_position_to_robot(self, board_point: tuple[float, float]) -> dict[str, float]:
        """Convert continuous board coordinates, where cell A1 is centred at 0.5,0.5."""
        grid = self.robot_grid
        anchor_column, anchor_row = grid["anchor_cell"]
        column_offset = board_point[0] - 0.5 - anchor_column
        row_offset = board_point[1] - 0.5 - anchor_row
        position = (
            grid["anchor"]
            + column_offset * grid["column_step"]
            + row_offset * grid["row_step"]
        )
        return {
            "x": round(float(position[0]), 2),
            "y": round(float(position[1]), 2),
            "z": round(float(position[2]), 2),
            "r": self.r,
        }

    def cell_to_robot(self, cell: tuple[int, int]) -> dict[str, float]:
        column, row = cell
        if getattr(self, "robot_grid", None) is not None:
            return self._board_position_to_robot((column + 0.5, row + 0.5))
        x, y = self._transform(
            (column + 0.5, row + 0.5), self.board_to_robot
        )
        return {"x": round(x, 2), "y": round(y, 2), "r": self.r}

    def board_to_pixel(self, point: tuple[float, float]) -> tuple[int, int]:
        x, y = self._transform(point, self.board_to_image)
        return round(x), round(y)

    def cell_polygon(self, cell: tuple[int, int]):
        column, row = cell
        points = [
            self.board_to_pixel((column, row)),
            self.board_to_pixel((column + 1, row)),
            self.board_to_pixel((column + 1, row + 1)),
            self.board_to_pixel((column, row + 1)),
        ]
        return np.asarray(points, dtype=np.int32)

    def build_move_json(
        self,
        start: tuple[int, int],
        target: tuple[int, int],
        is_capture: bool,
        graveyard_index: int = 0,
    ) -> dict:
        payload = {
            "schema_version": 1,
            "type": "move_command",
            "timestamp": utc_timestamp(),
            "is_capture": is_capture,
            "safe_z": self.safe_z,
            "board_z": self.board_z,
            "start": self.cell_to_robot(start),
            "target": self.cell_to_robot(target),
        }
        if is_capture:
            payload["graveyard"] = self.graveyard_slot(graveyard_index)
            payload["graveyard_index"] = graveyard_index
        return payload


def graveyard_offset(index: int, spacing: float) -> tuple[float, float]:
    """Return centre-first grid offsets for captured pieces."""
    if index == 0:
        return 0.0, 0.0

    ring = 1
    remaining = index - 1
    while True:
        cells_in_ring = 8 * ring
        if remaining < cells_in_ring:
            break
        remaining -= cells_in_ring
        ring += 1

    positions = [
        (ring, 0),
        (-ring, 0),
        (0, ring),
        (0, -ring),
        (ring, ring),
        (-ring, ring),
        (ring, -ring),
        (-ring, -ring),
    ]
    for x in range(-ring + 1, ring):
        positions.append((x, ring))
        positions.append((x, -ring))
    for y in range(-ring + 1, ring):
        positions.append((ring, y))
        positions.append((-ring, y))

    dx, dy = positions[remaining]
    return dx * spacing, dy * spacing


class WebSocketMoveSender:
    def __init__(self, url: str | None):
        self.url = url
        self.connection = None

    async def send(self, payload: dict) -> None:
        message = json.dumps(payload, indent=2)
        print(f"Move JSON:\n{message}")
        if not self.url:
            return
        try:
            if self.connection is None:
                self.connection = await websockets.connect(self.url)
                print(f"WebSocket connected: {self.url}")
            await self.connection.send(json.dumps(payload))
            print("Move JSON sent")
        except Exception as error:
            self.connection = None
            print(f"WebSocket send failed: {error}")

    async def close(self) -> None:
        if self.connection is not None:
            await self.connection.close()
            self.connection = None


def utc_timestamp() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds").replace(
        "+00:00", "Z"
    )


def build_detection_json(
    detections: list[dict],
    frame_id: int,
    frame_shape: tuple[int, ...],
    camera_model: str,
    camera_serial: str,
    calibration: BoardCalibration | None = None,
) -> dict:
    """Build the JSON-safe camera-to-WebSocket object-coordinate contract."""
    height, width = frame_shape[:2]
    label_counts: dict[str, int] = {}
    objects = []
    ordered_detections = sorted(
        detections, key=lambda item: (item["label"], item["center"][0], item["center"][1])
    )
    resolved = []
    for detection in ordered_detections:
        center = tuple(int(value) for value in detection["center"])
        cell = (
            calibration.pixel_to_cell(center)
            if calibration is not None
            else cell_from_center(center, frame_shape)
        )
        resolved.append((detection, center, cell))
    occupied_cells = {cell for _, _, cell in resolved if cell is not None}

    for detection, center, cell in resolved:
        label = str(detection["label"])
        label_counts[label] = label_counts.get(label, 0) + 1
        box = tuple(int(value) for value in detection["box"])
        board = None
        robot = None
        if calibration is not None:
            board_x, board_y = calibration.pixel_to_board(center)
            board = {"x": round(board_x, 4), "y": round(board_y, 4)}
            if cell is not None:
                robot = calibration.pixel_to_robot(center)

        target_cell = next_target_cell(label, cell, occupied_cells)
        target = None
        if target_cell is not None:
            target = {
                "grid": {
                    "column": target_cell[0],
                    "row": target_cell[1],
                    "name": cell_name(target_cell),
                },
                "robot": (
                    calibration.cell_to_robot(target_cell)
                    if calibration is not None
                    else None
                ),
            }

        objects.append(
            {
                "id": f"{label.replace(' ', '_')}_{label_counts[label]}",
                "label": label,
                "confidence": round(float(detection["confidence"]), 4),
                "pixel": {
                    "center": {"x": center[0], "y": center[1]},
                    "bbox": {"x1": box[0], "y1": box[1], "x2": box[2], "y2": box[3]},
                },
                "normalized": {
                    "x": round(center[0] / width, 6),
                    "y": round(center[1] / height, 6),
                },
                "board": board,
                "grid": (
                    None
                    if cell is None
                    else {"column": cell[0], "row": cell[1], "name": cell_name(cell)}
                ),
                "robot": robot,
                "target": target,
            }
        )

    return {
        "schema_version": 1,
        "type": "object_detection",
        "timestamp": utc_timestamp(),
        "frame_id": frame_id,
        "camera": {"model": camera_model, "serial": camera_serial},
        "image": {"width": width, "height": height},
        "object_count": len(objects),
        "objects": objects,
    }


def cell_name(cell: tuple[int, int] | None) -> str:
    if cell is None:
        return "unknown"
    column, row = cell
    return f"{chr(ord('A') + column)}{row + 1}"


def cell_from_center(
    center: tuple[int, int], frame_shape: tuple[int, ...]
) -> tuple[int, int]:
    height, width = frame_shape[:2]
    x, y = center
    column = min(GRID_SIZE - 1, max(0, int(x * GRID_SIZE / width)))
    row = min(GRID_SIZE - 1, max(0, int(y * GRID_SIZE / height)))
    return column, row


def next_target_cell(
    label: str,
    current: tuple[int, int] | None,
    occupied: set[tuple[int, int]],
) -> tuple[int, int] | None:
    """Choose the nearest deterministic legal target that is inside and empty."""
    if current is None:
        return None
    column, row = current
    if label == "green block":
        candidates = [
            (column - 1, row + 1),
            (column + 1, row + 1),
            (column - 1, row - 1),
            (column + 1, row - 1),
        ]
    elif label == "blue block":
        candidates = [
            (column + 1, row),
            (column, row + 1),
            (column - 1, row),
            (column, row - 1),
        ]
    else:
        candidates = [(column + 1, row)]
    return next(
        (
            candidate
            for candidate in candidates
            if 0 <= candidate[0] < GRID_SIZE
            and 0 <= candidate[1] < GRID_SIZE
            and candidate not in occupied
        ),
        None,
    )


def follows_movement_rule(
    label: str, start: tuple[int, int], destination: tuple[int, int]
) -> bool:
    dc = destination[0] - start[0]
    dr = destination[1] - start[1]
    if dc == 0 and dr == 0:
        return False
    if label == "green block":
        return abs(dc) == abs(dr)
    if label == "blue block":
        return (dc == 0) != (dr == 0)
    return False


def nearest_legal_cell(
    label: str, start: tuple[int, int], attempted: tuple[int, int]
) -> tuple[int, int]:
    options = []
    for row in range(GRID_SIZE):
        for column in range(GRID_SIZE):
            cell = (column, row)
            if follows_movement_rule(label, start, cell):
                distance = abs(column - attempted[0]) + abs(row - attempted[1])
                options.append((distance, cell))
    return min(options, key=lambda item: item[0])[1]


def validate_move(
    actor: str,
    label: str,
    start: tuple[int, int],
    destination: tuple[int, int],
) -> tuple[bool, str]:
    if OWNER[label] != actor:
        return False, f"{actor} cannot move {label}; only {OWNER[label]} can"
    if not follows_movement_rule(label, start, destination):
        rule = "diagonally" if label == "green block" else "straight"
        return False, f"{label} must move {rule}"
    return True, "legal move"


class RuleController:
    def __init__(self, confirm_frames: int, missing_frames: int):
        labels = tuple(OWNER)
        self.confirm_frames = confirm_frames
        self.missing_frames = missing_frames
        self.accepted = {label: None for label in labels}
        self.candidate = {label: None for label in labels}
        self.candidate_count = {label: 0 for label in labels}
        self.missing_count = {label: 0 for label in labels}
        self.alert = {label: "" for label in labels}
        self.last_rejected = {label: None for label in labels}
        self.last_event = "Waiting for stable block positions"

    def reset(self) -> None:
        for label in OWNER:
            self.accepted[label] = None
            self.candidate[label] = None
            self.candidate_count[label] = 0
            self.missing_count[label] = 0
            self.alert[label] = ""
            self.last_rejected[label] = None
        self.last_event = "Grid state reset; waiting for baseline"

    def update(
        self,
        detections: list[dict],
        actor: str,
        frame_shape,
        calibration: BoardCalibration | None = None,
    ) -> list[dict]:
        move_events = []
        best = {}
        for detection in detections:
            label = detection["label"]
            if label in OWNER and (
                label not in best
                or detection["confidence"] > best[label]["confidence"]
            ):
                best[label] = detection

        for label in OWNER:
            detection = best.get(label)
            if detection is None:
                self.candidate[label] = None
                self.candidate_count[label] = 0
                self.missing_count[label] += 1
                if (
                    self.missing_count[label] == self.missing_frames
                    and self.accepted[label] is not None
                    and OWNER[label] != actor
                ):
                    self.alert[label] = (
                        f"NOT ALLOWED: {actor} picked up {label.upper()}. "
                        f"RETURN IT TO {cell_name(self.accepted[label])}"
                    )
                    self.last_event = self.alert[label]
                continue

            self.missing_count[label] = 0
            if calibration is None:
                observed = cell_from_center(detection["center"], frame_shape)
            else:
                observed = calibration.pixel_to_cell(detection["center"])
                if observed is None:
                    continue
            if observed == self.candidate[label]:
                self.candidate_count[label] += 1
            else:
                self.candidate[label] = observed
                self.candidate_count[label] = 1

            if self.candidate_count[label] < self.confirm_frames:
                continue
            if self.accepted[label] is None:
                self.accepted[label] = observed
                self.alert[label] = ""
                self.last_event = f"Baseline: {label} at {cell_name(observed)}"
                continue
            if observed == self.accepted[label]:
                if self.alert[label]:
                    self.last_event = f"Corrected: {label} returned to {cell_name(observed)}"
                self.alert[label] = ""
                self.last_rejected[label] = None
                continue

            rejection_key = (actor, self.accepted[label], observed)
            if rejection_key == self.last_rejected[label]:
                continue

            allowed, reason = validate_move(
                actor, label, self.accepted[label], observed
            )
            if allowed:
                start = self.accepted[label]
                is_capture = any(
                    other_label != label and other_cell == observed
                    for other_label, other_cell in self.accepted.items()
                )
                self.accepted[label] = observed
                self.alert[label] = ""
                self.last_rejected[label] = None
                self.last_event = (
                    f"LEGAL: {actor} moved {label} "
                    f"{cell_name(start)} -> {cell_name(observed)}"
                )
                move_events.append(
                    {
                        "actor": actor,
                        "label": label,
                        "start": start,
                        "target": observed,
                        "is_capture": is_capture,
                    }
                )
            else:
                correction = nearest_legal_cell(
                    label, self.accepted[label], observed
                )
                self.alert[label] = (
                    f"NOT ALLOWED: {reason.upper()}. RETURN TO "
                    f"{cell_name(self.accepted[label])} OR MOVE TO "
                    f"{cell_name(correction)}"
                )
                self.last_rejected[label] = rejection_key
                self.last_event = self.alert[label]
        return move_events


def draw_grid(
    image,
    controller: RuleController,
    actor: str,
    calibration: BoardCalibration | None = None,
) -> None:
    height, width = image.shape[:2]
    cell_width = width / GRID_SIZE
    cell_height = height / GRID_SIZE

    overlay = image.copy()
    accepted_colors = {
        "blue block": (255, 80, 0),
        "green block": (0, 180, 0),
    }
    for label, cell in controller.accepted.items():
        if cell is None:
            continue
        if calibration is None:
            column, row = cell
            x1, y1 = int(column * cell_width), int(row * cell_height)
            x2, y2 = int((column + 1) * cell_width), int((row + 1) * cell_height)
            cv2.rectangle(overlay, (x1, y1), (x2, y2), accepted_colors[label], -1)
        else:
            cv2.fillConvexPoly(
                overlay, calibration.cell_polygon(cell), accepted_colors[label]
            )
    cv2.addWeighted(overlay, 0.12, image, 0.88, 0, image)

    for index in range(GRID_SIZE + 1):
        if calibration is None:
            x = round(index * cell_width)
            y = round(index * cell_height)
            vertical = ((x, 0), (x, height))
            horizontal = ((0, y), (width, y))
        else:
            vertical = (
                calibration.board_to_pixel((index, 0)),
                calibration.board_to_pixel((index, GRID_SIZE)),
            )
            horizontal = (
                calibration.board_to_pixel((0, index)),
                calibration.board_to_pixel((GRID_SIZE, index)),
            )
        cv2.line(image, *vertical, (0, 255, 255), 3, cv2.LINE_AA)
        cv2.line(image, *horizontal, (0, 255, 255), 3, cv2.LINE_AA)
    for row in range(GRID_SIZE):
        for column in range(GRID_SIZE):
            if calibration is None:
                label_position = (
                    int(column * cell_width) + 14,
                    int(row * cell_height) + 38,
                )
            else:
                label_position = calibration.board_to_pixel(
                    (column + 0.12, row + 0.30)
                )
            cv2.putText(
                image, cell_name((column, row)),
                label_position,
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2, cv2.LINE_AA,
            )

    cv2.rectangle(image, (0, 0), (width, 115), (0, 0, 0), -1)
    cv2.putText(
        image, f"MODE: {actor}   H=human  R=robot  X=reset  Q=quit", (18, 36),
        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA,
    )
    cv2.putText(
        image, "HUMAN: blue straight   |   ROBOT: green diagonal", (18, 72),
        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2, cv2.LINE_AA,
    )
    cv2.putText(
        image, controller.last_event[:110], (18, 105),
        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (160, 255, 160), 2, cv2.LINE_AA,
    )

    alerts = [message for message in controller.alert.values() if message]
    if alerts:
        message = alerts[-1]
        y1, y2 = height // 2 - 55, height // 2 + 55
        cv2.rectangle(image, (0, y1), (width, y2), (0, 0, 210), -1)
        cv2.putText(
            image, message[:105], (24, height // 2 + 10),
            cv2.FONT_HERSHEY_SIMPLEX, 0.85, (255, 255, 255), 3, cv2.LINE_AA,
        )


def draw_robot_coordinates(
    image, detections: list[dict], calibration: BoardCalibration
) -> None:
    for detection in detections:
        if detection["label"] not in OWNER:
            continue
        cell = calibration.pixel_to_cell(detection["center"])
        if cell is None:
            continue
        coordinate = calibration.cell_to_robot(cell)
        center_x, center_y = detection["center"]
        text = (
            f"{cell_name(cell)}  MG400 "
            f"X={coordinate['x']:.2f} Y={coordinate['y']:.2f}"
        )
        cv2.putText(
            image, text, (center_x + 10, center_y - 12),
            cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255, 255, 0), 2, cv2.LINE_AA,
        )


def run_self_test() -> None:
    blue_test = np.full((10, 10, 3), (255, 0, 0), dtype=np.uint8)
    green_test = np.full((10, 10, 3), (0, 255, 0), dtype=np.uint8)
    assert measured_color(blue_test, None, (0, 0, 10, 10), 0)[0] == 1
    assert measured_color(green_test, None, (0, 0, 10, 10), 1)[0] == 0
    assert not validate_move("HUMAN", "blue block", (0, 0), (1, 1))[0]
    assert validate_move("HUMAN", "blue block", (0, 0), (1, 0))[0]
    assert not validate_move("HUMAN", "green block", (0, 0), (0, 2))[0]
    assert not validate_move("ROBOT", "green block", (0, 0), (0, 2))[0]
    assert validate_move("ROBOT", "green block", (0, 0), (1, 1))[0]
    assert nearest_legal_cell("green block", (0, 0), (1, 1)) == (1, 1)

    controller = RuleController(confirm_frames=1, missing_frames=2)
    frame_shape = (400, 400, 3)
    baseline = [
        {"label": "blue block", "confidence": 0.9, "center": (50, 50)},
        {"label": "green block", "confidence": 0.9, "center": (350, 50)},
    ]
    controller.update(baseline, "HUMAN", frame_shape)
    controller.update(
        [
            {"label": "blue block", "confidence": 0.9, "center": (150, 50)},
            {"label": "green block", "confidence": 0.9, "center": (350, 50)},
        ],
        "HUMAN",
        frame_shape,
    )
    assert controller.accepted["blue block"] == (1, 0)
    controller.update(
        [{"label": "green block", "confidence": 0.9, "center": (350, 250)}],
        "HUMAN",
        frame_shape,
    )
    assert controller.accepted["green block"] == (3, 0)
    assert controller.alert["green block"].startswith("NOT ALLOWED")
    detection_payload = build_detection_json(
        [
            {
                "label": "blue block",
                "confidence": 0.91,
                "center": (150, 250),
                "box": (100, 200, 200, 300),
            }
        ],
        frame_id=7,
        frame_shape=frame_shape,
        camera_model="test-camera",
        camera_serial="test-serial",
    )
    assert detection_payload["type"] == "object_detection"
    assert detection_payload["objects"][0]["grid"]["name"] == "B3"
    assert detection_payload["objects"][0]["pixel"]["center"] == {"x": 150, "y": 250}
    json.dumps(detection_payload)

    calibration = BoardCalibration.__new__(BoardCalibration)
    image_corners = np.asarray(
        [[0, 0], [400, 0], [400, 400], [0, 400]], dtype=np.float32
    )
    board_corners = np.asarray(
        [[0, 0], [4, 0], [4, 4], [0, 4]], dtype=np.float32
    )
    robot_corners = np.asarray(
        [[100, 200], [140, 200], [140, 240], [100, 240]], dtype=np.float32
    )
    calibration.image_to_board = cv2.getPerspectiveTransform(
        image_corners, board_corners
    )
    calibration.board_to_image = cv2.getPerspectiveTransform(
        board_corners, image_corners
    )
    calibration.board_to_robot = cv2.getPerspectiveTransform(
        board_corners, robot_corners
    )
    calibration.r = 5.0
    calibrated_payload = build_detection_json(
        [
            {
                "label": "blue block",
                "confidence": 0.9,
                "center": (50, 50),
                "box": (25, 25, 75, 75),
            }
        ],
        8,
        frame_shape,
        "test-camera",
        "test-serial",
        calibration,
    )
    assert calibrated_payload["objects"][0]["board"] == {"x": 0.5, "y": 0.5}
    assert calibrated_payload["objects"][0]["robot"] == {
        "x": 105.0,
        "y": 205.0,
        "r": 5.0,
    }
    assert calibrated_payload["objects"][0]["target"] == {
        "grid": {"column": 1, "row": 0, "name": "B1"},
        "robot": {"x": 115.0, "y": 205.0, "r": 5.0},
    }
    assert next_target_cell("green block", (2, 0), {(2, 0)}) == (1, 1)
    assert next_target_cell("blue block", (1, 1), {(1, 1)}) == (2, 1)
    assert graveyard_offset(0, 25.0) == (0.0, 0.0)
    assert graveyard_offset(1, 25.0) == (25.0, 0.0)
    assert graveyard_offset(2, 25.0) == (-25.0, 0.0)
    print("Self-test passed: rules and object-coordinate JSON are correct")


async def run_live(args) -> None:
    calibration = None
    if args.calibration.exists():
        calibration = BoardCalibration(args.calibration)
    else:
        print(
            f"Calibration not found: {args.calibration}. "
            "Sending pixel and approximate 4x4 grid coordinates only."
        )
    sender = WebSocketMoveSender(args.websocket)

    reference = cv2.imread(str(args.reference))
    camera = create_camera(
        args.camera_type,
        args.camera_index,
        args.camera_width,
        args.camera_height,
        args.camera_fps,
        args.mvs_device_index,
        args.serial,
    )
    try:
        if reference is None:
            print(
                f"Reference image not found: {args.reference}. "
                "Using the first camera frame as the green/blue visual prompt."
            )
            reference = read_camera_frame(camera)
        model = prepare_yolo(reference, args.model)
    except Exception:
        camera.close()
        raise
    controller = RuleController(args.confirm_frames, args.missing_frames)
    actor = "HUMAN"
    started = time.monotonic()
    last_detection_sent = 0.0
    frame_id = 0
    latest = None

    print(f"Connected: {camera.model} ({camera.serial})")
    print("4x4 rule grid live. H=human, R=robot, X=reset, S=save, Q=quit")
    try:
        while True:
            frame = read_camera_frame(camera)
            frame_id += 1
            result = model.predict(
                frame, conf=args.confidence, imgsz=640, verbose=False
            )[0]
            latest, detections = annotate(frame, result)
            move_events = controller.update(
                detections, actor, frame.shape, calibration
            )
            draw_grid(latest, controller, actor, calibration)
            if calibration is not None:
                draw_robot_coordinates(latest, detections, calibration)

            now = time.monotonic()
            if (
                args.send_detections
                and now - last_detection_sent >= args.detection_interval
            ):
                detection_payload = build_detection_json(
                    detections,
                    frame_id,
                    frame.shape,
                    camera.model,
                    camera.serial,
                    calibration,
                )
                await sender.send(detection_payload)
                last_detection_sent = now

            for event in move_events:
                if args.send_actor != "BOTH" and event["actor"] != args.send_actor:
                    continue
                if calibration is None:
                    print("Move not sent: board_calibration.json is required for robot X/Y")
                    continue
                payload = calibration.build_move_json(
                    event["start"], event["target"], event["is_capture"]
                )
                await sender.send(payload)

            if not args.no_window:
                cv2.imshow("4x4 Human / Robot block rules", fit_preview(latest))
                key = cv2.waitKey(1) & 0xFF
                if key in (ord("q"), ord("Q"), 27):
                    break
                if key in (ord("h"), ord("H")):
                    actor = "HUMAN"
                    controller.last_event = "Human mode selected: move only blue"
                elif key in (ord("r"), ord("R")):
                    actor = "ROBOT"
                    controller.last_event = "Robot mode selected: move only green"
                elif key in (ord("x"), ord("X")):
                    controller.reset()
                elif key in (ord("s"), ord("S")):
                    cv2.imwrite(str(args.output), latest)
                    print(f"Saved: {args.output.resolve()}")

            if args.duration > 0 and time.monotonic() - started >= args.duration:
                break
            await asyncio.sleep(0)
    finally:
        if latest is not None:
            cv2.imwrite(str(args.output), latest)
            print(f"Latest grid frame: {args.output.resolve()}")
        await sender.close()
        cv2.destroyAllWindows()
        camera.close()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--camera-type",
        choices=("auto", "opencv", "hikrobot"),
        default=config.CAMERA_TYPE,
    )
    parser.add_argument("--camera-index", type=int, default=config.CAMERA_INDEX)
    parser.add_argument("--camera-width", type=int, default=config.CAMERA_WIDTH)
    parser.add_argument("--camera-height", type=int, default=config.CAMERA_HEIGHT)
    parser.add_argument("--camera-fps", type=int, default=config.CAMERA_FPS)
    parser.add_argument("--mvs-device-index", type=int, default=config.MVS_DEVICE_INDEX)
    parser.add_argument(
        "--serial",
        default=config.HIKROBOT_SERIAL,
        help="Optional Hikrobot camera serial. Ignored for OpenCV cameras.",
    )
    parser.add_argument("--model", type=Path, default=Path("yoloe-11s-seg.pt"))
    parser.add_argument("--reference", type=Path, default=Path("mvs_test_frame.jpg"))
    parser.add_argument("--confidence", type=float, default=0.15)
    parser.add_argument("--confirm-frames", type=int, default=3)
    parser.add_argument("--missing-frames", type=int, default=8)
    parser.add_argument("--duration", type=float, default=0.0)
    parser.add_argument("--no-window", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--output", type=Path, default=Path("mvs_grid_latest.jpg"))
    parser.add_argument(
        "--calibration", type=Path, default=Path("board_calibration.json")
    )
    parser.add_argument(
        "--websocket",
        default="ws://127.0.0.1:8765",
        help="WebSocket server URL; use an empty string to print JSON only",
    )
    parser.add_argument(
        "--send-actor",
        choices=("HUMAN", "ROBOT", "BOTH"),
        default="ROBOT",
        help="Which accepted moves are sent through WebSocket",
    )
    parser.add_argument(
        "--send-detections",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Send detected object coordinates over WebSocket (default: enabled)",
    )
    parser.add_argument(
        "--detection-interval",
        type=float,
        default=0.5,
        help="Minimum seconds between object_detection JSON messages",
    )
    args = parser.parse_args()

    if args.detection_interval <= 0:
        parser.error("--detection-interval must be greater than zero")

    if args.self_test:
        run_self_test()
        return

    asyncio.run(run_live(args))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Stopped by user")
    except Exception as error:
        print(f"ERROR: {error}")
        raise SystemExit(1)
